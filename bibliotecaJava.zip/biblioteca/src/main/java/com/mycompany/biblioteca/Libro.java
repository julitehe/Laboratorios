/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author xsraws
 */
public class Libro {
      // Atributos
    private String titulo;
    private String autor;
    private String codigo;
    private int añoPubli;
    private int numEjemplares;
    private int numDisponibles;
    
    // Constructor
    public Libro(String t, String au, String cod, int ap, int numEj){
        this.titulo = t;
        this.autor = au;
        this.codigo = cod;
        this.añoPubli = ap;
        this.numEjemplares = numEj;
    }
    
    // Métodos (Gettings y Settings)
    public String getTitulo(){
        return titulo;}
    
    public String getAutor(){
        return autor;}
    
    public String getCodigo(){
        return codigo;}
    
    public int getAñoPubli(){
        return añoPubli;}
    
    public int getNumEjemplares(){
        return numEjemplares;}
    
    public int getNumDisponibles(){
        return numDisponibles;}
    
    public void setTitulo(String t){
        this.titulo=t;}
    
    public void setAutor(String a){
        this.autor=a;}
    
    public void setCodigo(String c){
        this.codigo=c;}
    
    public void setAñoPubli(int a){
        this.añoPubli=a;}
    
    public void setNumEjemplares(int ej){
        this.numEjemplares=ej;}
    
    public void setNumDisponibles(int di){
        this.numDisponibles=di;}
    
    
    @Override
    public String toString(){
        return "Libro: \nTitulo: " + titulo +", " +  autor + "\nCódigo: " + codigo + 
                "\nAño de publicación: " + añoPubli +
                "\nTotal de ejemplares: " + numEjemplares;
               
    }
    
}
