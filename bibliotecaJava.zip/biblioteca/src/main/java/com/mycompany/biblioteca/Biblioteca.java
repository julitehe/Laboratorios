/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.biblioteca;
import java.util.Scanner;
/**
 *
 * @author xsraws
 */
public class Biblioteca {

    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner sc = new Scanner(System.in);
        Menu menu = new Menu(sistema);
        
        
        // Libros existentes
        sistema.agregarLibro("Cálculo: Conceptos y contextos", "James Stewart", "CIE", 2009, 3);
        sistema.agregarLibro("Álgebra lineal: Una introducción moderna", "David Poole", "ALIM11", 2011, 2);
        sistema.agregarLibro("Macroeconomía", "Olivier Blanchard", "HUM-MAC-M-OB-17", 2017, 2);
        sistema.agregarLibro("Arquitectura: forma, espacio y orden", "Francis D. K. Ching", "AFEO", 2015, 3);
        sistema.agregarLibro("Fundamentos de Física", "David Halliday, Robert Resnick, Jearl Walker", "CIE-FIS-FDF-DHRRJW-14", 2014, 2);
        
        sistema.agregarUsuario("AdminA", "admi123");
        sistema.agregarUsuario("ProfeB", "profe123");
        sistema.agregarUsuario("Camila", "estu123");
        
        System.out.println("Ingresa tu usuario: ");
        String nombre = sc.nextLine();
        System.out.println("Ingresa tu contraseña: ");
        String cont = sc.nextLine();
        
        if(sistema.logIn(nombre, cont) == 0){
            menu.menuAdmin();
        }
        else{
            menu.menuOtros();}
            
    }
}
