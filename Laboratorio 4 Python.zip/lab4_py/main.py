from Progresion import *

prog = Progresion(6)
print("Progresion:")
prog.imprimirP(5)

prog = Aritmetica(3,7)
print("Aritmetica:")
prog.imprimirP(6)

prog = Geometrica(6,3)
print("Geometrica:")
prog.imprimirP(5)

prog = Fibonacci()
print("Fibonacci:")
prog.imprimirP(10)