/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.laboratorio4;

/**
 *
 * @author julia
 */
public class Geometrica extends Progresion {
   protected long base;
   // constructores
   public Geometrica(){
       valor = 1;
       base = 1;
   }
   public Geometrica(long b){
       valor = 1;
       base = b;
   }
   public Geometrica(long b, long s){
       base = b;
       valor = s;
   }
   
   @Override
   protected void avanzar(){
       valor *= base;
   }

}
