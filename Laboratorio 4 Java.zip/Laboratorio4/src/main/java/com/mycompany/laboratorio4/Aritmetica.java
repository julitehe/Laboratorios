package com.mycompany.laboratorio4;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julia
 */
public class Aritmetica extends Progresion{
    
    protected long incremento;
    
    public Aritmetica(){
        incremento = 1;
    }
    
    public Aritmetica(long in){
        incremento = in;
    }
    
    public Aritmetica(long in, long s){
        incremento = in;
        valor = s;
    }
    
    @Override
    protected void avanzar(){
        valor += incremento;
    }
}
