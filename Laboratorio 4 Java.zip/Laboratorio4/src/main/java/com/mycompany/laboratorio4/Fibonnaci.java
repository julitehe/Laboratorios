/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.laboratorio4;

/**
 *
 * @author julia
 */
public class Fibonnaci extends Progresion{
    protected long prev;
    public Fibonnaci(){
        prev = 0;
        valor = 1;
    }
    
    @Override
    protected void avanzar(){
        long temp;
        temp = prev + valor;
        prev = valor;
        valor = temp;
        
    }
}
