/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.laboratorio4;

/**
 *
 * @author julia
 */
public class Laboratorio4 {
    public static void main(String[] args) {   
        Progresion prog = new Progresion(6);
        prog.imprimirP(5);
        Progresion arit = new Aritmetica(3, 7);
        arit.imprimirP(6);
        Progresion geo = new Geometrica(6, 3);
        geo.imprimirP(5);
        Progresion fib = new Fibonnaci();
        fib.imprimirP(10);
        
    }
}
