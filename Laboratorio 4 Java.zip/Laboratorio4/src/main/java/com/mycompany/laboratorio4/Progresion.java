package com.mycompany.laboratorio4;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author julia
 */
public class Progresion {
    //atributos
    long valor;
    
    //constructores
    public Progresion(){
        valor = 0;
    }
    
    public Progresion(long s){
        valor = s;
    }
    
    //metodos
    public long nextValor(){ //método público que retorna el valor actual de la progresión y calcula el siguiente (sigValor)
        long temp = valor;
        avanzar();
        return temp;
    }
    protected void avanzar(){ //método protegido que es el responsable de calcular el siguiente valor de la progresión y actualizar el atributo valor
        valor++;
    }
    public void imprimirP(int n){ //método público que calcula los n siguientes elementos de la progresión y muestra en pantalla estos valores
        for(int i = 1; i<=n; i++){
                System.out.print( nextValor() + " ");
        }
        System.out.print("\n");
    }
}
