/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.laboratorio5;

/**
 *
 * @author julia
 */
public class Laboratorio5 {

    public static void main(String[] args) {
        Progresion ar = new Aritmetica(3, 5);
        ar.imprimirP(3);
        Progresion ge = new Geometrica(2, 3);
        ge.imprimirP(3);
        Progresion fi = new Fibonnaci();
        fi.imprimirP(10);
    }
}
