from Fecha import Fecha
from Direccion import Direccion
from Usuario import Usuario

# punto A

mi_fecha = Fecha(22, 12, 2006)

print(mi_fecha)

mi_dir = Direccion()

mi_dir.calle = "13"
mi_dir.nomenclatura = "44-85"
mi_dir.barrio = "La colinita"
mi_dir.ciudad = "Medellín"
mi_dir.edificio = "Zannetii"
mi_dir.apto = "26-11"

print(mi_dir)

user1 = Usuario("juli", 23123)

user1.fecha_nacimiento = mi_fecha
user1.ciudad_nacimiento = "Pasto"
user1.tel = 3128383291
user1.email = "sbibim@gmail.com"
user1.dir = mi_dir

print(user1)

# punto B
print("-------------------------------")
print("Ingrese sus datos de usuario:")
nombre = input("Nombre: ")
id = input("Id: ")
tel = input("Teléfono: ")

user2 = Usuario(nombre, id)

user2.tel = tel
email = input("Email: ")
user2.email = email

print("Ingrese datos de nacimiento:")
ciudad_nac = input("Ciudad de nacimiento: ")
user2.ciudad_nacimiento =  ciudad_nac
dia = input("Día: ")
mes = input("Mes: ")
a = input("Año: ")

fecha_nac = Fecha(dia, mes, a)
user2.fecha_nacimiento = fecha_nac

print("Ingrese los datos de su dirección:")

direccion_usuario = Direccion()

calle = input("Calle: ")
direccion_usuario.calle = calle
nomenclatura = input("Nomenclatura: ")
direccion_usuario.nomenclatura = nomenclatura
barrio = input("Barrio: ")
direccion_usuario.barrio = barrio
ciudad = input("Ciudad: ")
direccion_usuario.ciudad = ciudad
edificio = input("Edificio: ")
direccion_usuario.edificio = edificio
apto = input("Apto: ")
direccion_usuario.apto = apto

user2.dir = direccion_usuario

print("-------------------------------")
print(user2)

