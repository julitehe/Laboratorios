class Direccion:
    # constructor
    def __init__(self):
        # atributos
        self.__calle = None
        self.__nomenclatura = None
        self.__barrio = None
        self.__ciudad = None
        self.__edificio = None
        self.__apto = None

    # settings
    def calle(self, c):
        self.__calle = c
    def nomenclatura(self, n):
        self.__nomenclatura = n
    def barrio(self, b):
        self.__barrio = b
    def ciudad(self, ci):
        self.__ciudad = ci
    def edificio(self, e):
        self.__edificio = e
    def apto(self, a):
        self.__apto = a

    # gettings
    def calle(self):
        return calle
    def nomenclatura(self):
        return nomenclatura
    def barrio(self):
        return barrio
    def ciudad(self):
        return ciudad
    def edificio(self):
        return edificio
    def apto(self):
        return apto
    
    #to string
    def __str__(self):
        return f"{self.calle} #{self.nomenclatura} {self.barrio}, {
            self.ciudad}, {self.edificio}-{self.apto}"
    