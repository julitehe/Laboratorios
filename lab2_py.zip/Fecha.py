class Fecha:
    #constructor
    def __init__(self, dd, mm, aa):
        #atributos
        self.__dd = dd
        self.__mm = mm
        self.__aa = aa

    # settings
    def dia(self, dd):
        self.dd = dd

    def mes(self, mm):
        self.mm = mm

    def a(self, aa):
        self.aa = aa

    # gettings
    def dia(self):
        return dd
    
    def mes(self):
        return mm
    
    def a(self):
        return aa
    
    # to string
    def __str__(self):
        return f"{self.__dd}-{self.__mm}-{self.__aa}"