class Usuario:
    def __init__(self, n, id):
        # Atributos
        self.__nombre = n
        self.__id = id
        self.__fecha_nacimiento = None
        self.__ciudad_nacimiento = None
        self.__tel = None
        self.__email = None
        self.__dir = None

    # Settings
    def nombre(self, n):
        self.__nombre = n
    def id(self, id):
        self.__id = id
    def fecha_nacimiento(self, f):
        self.__fecha_nacimiento = f
    def ciudad_nacimiento(self, c):
        self.__ciudad_nacimiento = c
    def tel(self, t):
        self.__tel = t
    def email(self, e):
        self.__email = e
    def dir(self, d):
        self.__dir = d

    # Gettings
    def nombre(self):
        return nombre
    def id(self):
        return id
    def fecha_nacimiento(self):
        return fecha_nacimiento
    def getCiudad_nacimiento(self):
        return ciudad_nacimiento
    def tel(self):
        return tel
    def email(self):
        return email
    def dir(self):
        return dir
    
    # to string
    def __str__(self):
        return f"Datos de contacto:\nNombre: {self.__nombre} Id: {self.__id
        }\nNacimiento: {self.fecha_nacimiento}, {self.ciudad_nacimiento
        }\nTeléfono: {self.tel} Email: {self.email}\nDirección: {self.dir}"


