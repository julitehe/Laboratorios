from Progresion import *
from Shape import *

prog = Aritmetica(3,5)
print("Aritmetica:")
prog.imprimirP(3)

prog = Geometrica(2,3)
print("Geometrica:")
prog.imprimirP(3)

prog = Fibonacci()
print("Fibonacci:")
prog.imprimirP(10)

figura = Circulo(2)
print("Circulo:")
figura.calcularArea()
figura.calcularPerimetro()

figura = Rectangulo(5, 10)
print("\nRectangulo:")
figura.calcularArea()
figura.calcularPerimetro()

figura = Triangulo(2, 3)
print("\nTriangulo:")
figura.calcularArea()
figura.calcularPerimetro()