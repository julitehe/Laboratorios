from abc import ABC, abstractmethod

class Progresion(ABC):
    def __init__(self, s):
        #s -> valor arbitrario para iniciar la progresion
        self._valor = s

    @abstractmethod
    def avanzar(self):
        pass

    def sigValor(self):
        temp = self._valor
        self.avanzar()
        return temp
    
    def imprimirP(self, n):
        for i in range(n):
            print(f"{self.sigValor()}", end=" ")
        print("\n")
        return ""
    
class Aritmetica(Progresion):
    def __init__(self, inc, s):
        super().__init__(s)
        self._incremento = inc

    def avanzar(self):
        self._valor += self._incremento 
        
    
class Geometrica(Progresion):
    def __init__(self, b, s):
        super().__init__(s)
        self._base = b
    
    def avanzar(self):
        self._valor *= self._base

class Fibonacci(Progresion):
    def __init__(self):
        super().__init__(0)
        self._prev = 1
    
    def avanzar(self):
        temp = self._valor + self._prev
        self._prev = self._valor
        self._valor = temp

    