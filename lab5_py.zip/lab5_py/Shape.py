from abc import ABC, abstractmethod
from math import pi 

class Shape(ABC):
    @abstractmethod
    def calcularPerimetro():
        pass
    @abstractmethod
    def calcularArea():
        pass

class Circulo(Shape):
    def __init__(self, r):
        super().__init__()
        self.__radio = r

    def calcularArea(self):
        print(f"Área: {round(pi * self.__radio ** 2, 3)}")
    
    def calcularPerimetro(self):
        print(f"Perimetro: {round(2 * pi * self.__radio, 3)}")
    
class Rectangulo(Shape):
    def __init__(self, b, a):
        super().__init__()
        self.__base = b
        self.__altura = a

    def calcularArea(self):
        print(f"Área: {self.__base * self.__altura}")
    
    def calcularPerimetro(self):
        print(f"Perímetro: {(2 * self.__base) + (2 * self.__altura)}")

class Triangulo(Shape):
    def __init__(self, b, a):
        super().__init__()
        self.__base = b
        self.__altura = a

    def calcularArea(self):
        print(f"Área: {(self.__base * self.__altura) / 2}")

    def calcularPerimetro(self):
        print(f"Perimetro: {self.__base * 3} (suponiendo un triangulo equilatero)")
    

    