import tkinter as tk
from tkinter import messagebox

class Interfaz(tk.Tk):
    def __init__(self, sis):
        super().__init__()
        self.__sistema = sis

        self.title("Login form")
        self.geometry("500x500")
        self.configure(bg="#F2E0E2")

        frame = tk.Frame(self, bg="#F2E0E2")
        frame.pack()

        # Widgets
        loginLabel = tk.Label(frame, text="Login", bg="#F2E0E2", fg="#F85AA9", font=("Arial", 20), pady=30)
        idLabel = tk.Label(frame, text="ID", bg="#F2E0E2", font=("Arial", 12), pady=15)
        self.idEntry = tk.Entry(frame, font=("Arial", 12))
        contraLabel = tk.Label(frame, text="Contraseña", bg="#F2E0E2", font=("Arial", 12), pady=15)
        self.contraEntry = tk.Entry(frame, show="*", font=("Arial", 12))

        loginButton = tk.Button(frame, text="Login", bg="#F85AA9", font=("Arial", 14), pady=10, command=self.login)
        questionLabel = tk.Label(frame, text="¿Aún no tienes una cuenta?",bg="#F2E0E2", font=("Arial", 10), pady=10)
        registroButton = tk.Button(frame, text="Registro", bg="#F85AA9", font=("Arial", 14), pady=10, command=self.formRegistro)

        # Widgets geometry
        loginLabel.grid(row=0, column=0, columnspan=2, sticky="news")
        idLabel.grid(row=1, column=0)
        self.idEntry.grid(row=1, column=1)
        contraLabel.grid(row=2, column=0)
        self.contraEntry.grid(row=2, column=1)
        loginButton.grid(row=3, column=0, columnspan=2)
        questionLabel.grid(row=4, column=0, columnspan= 2)
        registroButton.grid(row=5, column=0, columnspan=2)

    def login(self):
        id = self.idEntry.get() 
        contraseña = self.contraEntry.get()
        if(self.__sistema.logIn(id, contraseña)):
            messagebox.showinfo(title="Login Aprobado", message="Bienvenido al sistema")
        else:
            messagebox.showerror(title="Error", message="Login inválido")

    def formRegistro(self):
        windowRegistro = tk.Toplevel()
        windowRegistro.title("Registro")
        windowRegistro.geometry("340x440")
        windowRegistro.configure(bg="#F2E0E2")

        frame = tk.Frame(windowRegistro, bg="#F2E0E2")
        frame.pack()

        topLabel = tk.Label(frame, text="Ingrese sus datos", bg="#F2E0E2", fg="#F85AA9", font=("Arial", 20), pady=30)
        nomLabel = tk.Label(frame, text="Nombre", bg="#F2E0E2", font=("Arial", 12), pady=15)
        correoLabel = tk.Label(frame, text="Correo", bg="#F2E0E2", font=("Arial", 12), pady=15)
        idLabel = tk.Label(frame, text="ID", bg="#F2E0E2", font=("Arial", 12), pady=15)
        contraLabel = tk.Label(frame, text="Contraseña", bg="#F2E0E2", font=("Arial", 12), pady=15)
        self.nomEntry = tk.Entry(frame, font=("Arial", 12))
        self.correoEntry = tk.Entry(frame, font=("Arial", 12))
        self.idEntry = tk.Entry(frame, font=("Arial", 12))
        self.contraEntry = tk.Entry(frame, font=("Arial", 12))
        registroButton = tk.Button(frame, text="Registrar",  bg="#F85AA9", font=("Arial", 14), pady=10, command=self.registro)
        
        topLabel.grid(row=0, column=0, columnspan=2, sticky="news")
        nomLabel.grid(row=1, column=0)
        self.nomEntry.grid(row=1, column=1)
        correoLabel.grid(row=2, column=0)
        self.correoEntry.grid(row=2, column=1)
        idLabel.grid(row=3, column=0)
        self.idEntry.grid(row=3, column=1)
        contraLabel.grid(row=4, column=0)
        self.contraEntry.grid(row=4, column=1)
        registroButton.grid(row=5, column=0, columnspan=2)

    def registro(self):
        nom = self.nomEntry.get()
        correo = self.correoEntry.get()
        id = self.idEntry.get()
        contra = self.contraEntry.get()
        if not self.__sistema.registrarUsuario(nom, correo, id, contra):
            messagebox.showerror(title="Error", message="Por favor rellena todos los campos")
        else:
            print("registro completado")


    
