from Usuario import *
from Vuelo import *

class Sistema():
    def __init__(self):
        self.__usuarios = []
        self.__vuelos = []

    def buscarUsuario(self, id):
        for i in self.__usuarios:
            if i.id == id:
                return self.__usuarios.index(i)
        return -1 
            
    def registrarUsuario(self, nom, correo, id, cont):
        # que hacer si alguno de los datos llega vacio?
        if nom == "" or id == "" or correo == "" or cont == "":
            return False
        else:
            nuevo = Usuario(nom, id)
            nuevo.correo = correo
            nuevo.contraseña = cont
            self.__usuarios.append(nuevo)
            for u in range(len(self.__usuarios)):
                print(self.__usuarios[u].nombre)
            return True
    
    def mostrarPasajeros(self):
        pass

            
    def logIn(self, id, contraseña):
        if id == "": return False
        idx = self.buscarUsuario(id)
        if  idx == -1:
            print("incorrect id")
            return False
        return self.__usuarios[idx].contraseña == contraseña
    
    def mostrarVuelo(self, idx):
        #por el momento se imprimen en consola
        print(self.__vuelos[idx].__str__())
        
    def buscarVueloCiudad(self, origen, destino):
       for i in self.__vuelos:
           if i.origen == origen and i.destino == destino:
               self.mostrarVuelo(self.__vuelos.index(i))
           else:
               continue
         
    
    def buscarVueloCod(self, codigo):
        for i in self.__vuelos:
            if i.codigo == codigo:
                return self.__vuelos.index(i)
            else:
                continue
        
            
    def crearVuelo(self, codigo, origen, destino, dia, horario, sillasP, sillasEco):
        #como se va a recibir la info de los vuelos? agregar setters
        numP = sillasP + sillasEco
        nuevo = Vuelo(codigo, numP)
        nuevo.origen = origen
        nuevo.destino = destino
        nuevo.dia = dia
        nuevo.horario = horario
        nuevo.sillasPref = sillasP
        nuevo.sillasEco = sillasEco
        self.__vuelos.append(nuevo)
        return True
            
    def leerVuelos(self, filename):
        try:
            with open(filename, "r", encoding="utf-8") as archive:
                lineas = archive.readlines()

                for linea in lineas:
                    datos = linea.strip().split()
                    self.crearVuelo(datos[0], datos[1], datos[2], datos[3], datos[4], int(datos[5]), int(datos[6]))
                return True
        except Exception as e:
            print(f"Error: {e}")
            return False

    def editarVueloInfo(self, codigo):
        if Sistema.buscarVueloCod(codigo) == - 1:
            return False 
        else:
            #seleccion del componente que se va a editar
            return 1
    
    def consultarSillas(self, codigo):
        idx = Sistema.buscarVueloCod(codigo) 
        if idx == - 1:
            return False #que putas se hace
        else:
            return True
        
    


