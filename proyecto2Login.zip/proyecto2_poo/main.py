from Sistema import Sistema
from Interfaz import Interfaz

def main():
    sis = Sistema()  
    sis.registrarUsuario("J", "c", "1", "123")   
    sis.leerVuelos("vuelos.txt")
    sis.buscarVueloCiudad("MEDELLIN", "BOGOTA")
    aplicacion = Interfaz(sis) 
    aplicacion.mainloop()

if __name__ == "__main__":
    main()