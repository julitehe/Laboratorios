class Vuelo():
    def __init__(self, codigo, numP):
        self.__codigo = codigo
        self.__origen = None
        self.__destino = None
        self.__dia = None
        self.__horario = None
        self.__sillasPref = 0
        self.__sillasEco = 0
        self.__numPasajeros = numP
        self.__reservasVuelo = [None]

    @property
    def codigo(self):
        return self.__codigo
    @property
    def origen(self):
        return self.__origen
    
    @property
    def destino(self):
        return self.__destino
    
    @property
    def dia(self):
        return self.__dia
    
    @property
    def horario(self):
        return self.__horario
    
    @property
    def sillasPref(self):
        return self.__sillasPref
    
    @property
    def sillasEco(self):
        return self.__sillasEco
    
    @origen.setter
    def origen(self, o):
        self.__origen = o
    
    @destino.setter
    def destino(self, d):
        self.__destino = d

    @dia.setter
    def dia(self, d):
        self.__dia = d

    @horario.setter
    def horario(self, h):
        self.__horario = h

    @sillasPref.setter
    def sillasPref(self, pref):
        self.__horario = pref

    @sillasEco.setter
    def sillasEco(self, eco):
        self.__horario = eco

    def __str__(self):
        #prueba
        return f"Código: {self.__codigo} Origen: {self.__origen} Destino: {self.__destino} Horario: {self.__horario}"

 