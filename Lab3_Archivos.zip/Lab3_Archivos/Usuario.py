class Usuario:
    def __init__(self, n, id):
        # Atributos
        self.__nombre = n
        self.__id = id
        self.__fecha_nacimiento = None
        self.__ciudad_nacimiento = None
        self.__tel = None
        self.__email = None
        self.__dir = None

    # Settings
    def setNombre(self, n):
        self.__nombre = n
    def setId(self, id):
        self.__id = id
    def setFecha(self, f):
        self.__fecha_nacimiento = f
    def setCiudad(self, c):
        self.__ciudad_nacimiento = c
    def setTel(self, t):
        self.__tel = t
    def setEmail(self, e):
        self.__email = e
    def setDir(self, d):
        self.__dir = d

    # Gettings
    def getNombre(self):
        return self.__nombre
    def getId(self):
        return self.__id
    def getFecha_nacimiento(self):
        return self.__fecha_nacimiento
    def getCiudad_nacimiento(self):
        return self.__ciudad_nacimiento
    def getTel(self):
        return self.__tel
    def getEmail(self):
        return self.__email
    def getDir(self):
        return self.__dir
    
    # to string
    def __str__(self):
        return f"\nNombre: {self.__nombre} Id: {self.__id
        }\nNacimiento: {self.__fecha_nacimiento} {self.__ciudad_nacimiento
        }\nTeléfono: {self.__tel} Email: {self.__email}\nDirección: {self.__dir}\n"


