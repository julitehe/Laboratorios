class Fecha:
    #constructor
    def __init__(self, dd, mm, aa):
        #atributos
        self.__dd = dd
        self.__mm = mm
        self.__aa = aa

    # settings
    def setDia(self, dd):
        self.dd = dd

    def setMes(self, mm):
        self.mm = mm

    def setA(self, aa):
        self.aa = aa

    # gettings
    def getDia(self):
        return self.__dd
    
    def getMes(self):
        return self.__mm
    
    def getA(self):
        return self.__aa
    
    # to string
    def __str__(self):
        return f"{self.__dd}-{self.__mm}-{self.__aa}"