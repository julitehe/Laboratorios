from Usuario import *
class Agenda:
    # constructor
    def __init__(self, capacity):
        self.__registro = [None] * capacity
        self.__no_reg = 0
    
    def agregar(self, u):
        if Agenda.buscar(self, u.getId()) == -1 and self.__no_reg <= len(self.__registro):
            self.__registro[self.__no_reg] = u 
            self.__no_reg += 1 
            print("Usuario agregado correctamente") 
            return True 
        return False

    def buscar(self, id):
        for i in range(self.__no_reg):
            if self.__registro[i].getId() == id:
                return i
        return -1
    
    def eliminar(self, id):
        index = Agenda.buscar(self,id)
        if index != len(self.__registro):
            for j in range(index+1, len(self.__registro)):
                self.__registro[j-1] = self.__registro[j]
            self.__no_reg -= 1
            print("Usuario eliminado")
            return True
        else:
            return False
    
    def mostar(self):
        if self.__no_reg == 0:
            print("Agenda vacía")
        for i in range(self.__no_reg):
            print(f"Usuario #{i+1}\nNombre: {self.__registro[i].getNombre()} Id: {self.__registro[i].getId()}\n")
        
    def mostrarUsuario(self, id):
        index = Agenda.buscar(self, id)
        if index == -1:
            print("No se encontro el usuario")
        else:
            print(f"Información usario {self.__registro[index].getNombre()}: \n{self.__registro[index]})\n")

    def toFile(self, filename):
        try:
            with open(filename, "w") as archive:
                for i in range(self.__no_reg):
                    archive.write(f"=========================\nUser {i+1}")
                    archive.write(self.__registro[i].__str__())
                return True
        except Exception as e: 
                print("Error: {e}")
                return False
    
    def importText(self, filename):
        try:
            with open(filename, "r", encoding="utf-8") as archive:
                lineas = archive.readlines()
                i = 2
                user = 0

                while i  < len(lineas):
                    linea1 = lineas[i].strip().split()
                    linea2 = lineas[i+1].strip().split()
                    linea3 = lineas[i+2].strip().split()
                    linea4 = lineas[i+3].strip().replace("Direccion:", "")
                  
                    u = Usuario(linea1[1], int(linea1[-1]))
                    u.setFecha(linea2[1])
                    u.setCiudad(linea2[-1])
                    u.setTel(linea3[1])
                    u.setEmail(linea3[3])
                    u.setDir(linea4)
                    
                    self.__registro[user] = u
                    self.__no_reg += 1
                    user+=1
                    i+=6
                return True
               
        except Exception as e:
            print(f"Error: {e}")
            return False

    