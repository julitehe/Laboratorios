from Agenda import *
from Direccion import *
from Fecha import *
from Usuario import *

# Registro de usuarios
# Usuario 1 
user1 = Usuario("Sebastián", 98765)
fecha1 = Fecha(14, 3, 2006)
dir1 = Direccion()

dir1.setCalle("22")
dir1.setNomenclatura("56-90")
dir1.setBarrio("Los Álamos")
dir1.setCiudad("Medellín")
dir1.setEdificio("Montecarlo")
dir1.setApto("12-08")

user1.setFecha(fecha1)
user1.setDir(dir1)
user1.setCiudad("Pereira")
user1.setTel(3156784321)
user1.setEmail("sebastian_06@gmail.com")

# Usuario 2
user2 = Usuario("Carlos", 45211)
fecha2 = Fecha(15, 5, 2005)
dir2 = Direccion()

dir2.setCalle("45")
dir2.setNomenclatura("12-34")
dir2.setBarrio("Laureles")
dir2.setCiudad("Medellín")
dir2.setEdificio("Torre Verde")
dir2.setApto("8-04")

user2.setFecha(fecha2)
user2.setDir(dir2)
user2.setCiudad("Cali")
user2.setTel(3001234567)
user2.setEmail("carlos123@gmail.com")

# Usuario 3
user3 = Usuario("María", 83922)
fecha3 = Fecha(22, 9, 2004)
dir3 = Direccion()

dir3.setCalle("9")
dir3.setNomenclatura("21-18")
dir3.setBarrio("El Poblado")
dir3.setCiudad("Medellín")
dir3.setEdificio("Altavista")
dir3.setApto("15-02")

user3.setFecha(fecha3)
user3.setDir(dir3)
user3.setCiudad("Bogotá")
user3.setTel(3019876543)
user3.setEmail("maria_linda@gmail.com")

# Usuario 4
user4 = Usuario("Andrés", 73810)
fecha4 = Fecha(30, 11, 2006)
dir4 = Direccion()

dir4.setCalle("30")
dir4.setNomenclatura("70-15")
dir4.setBarrio("Belén")
dir4.setCiudad("Medellín")
dir4.setEdificio("Mirador")
dir4.setApto("10-07")

user4.setFecha(fecha4)
user4.setDir(dir4)
user4.setCiudad("Cartagena")
user4.setTel(3025556789)
user4.setEmail("andresito@gmail.com")

# Usuario 5
user5 = Usuario("Luisa", 92345)
fecha5 = Fecha(1, 2, 2003)
dir5 = Direccion()

dir5.setCalle("50")
dir5.setNomenclatura("88-22")
dir5.setBarrio("Robledo")
dir5.setCiudad("Medellín")
dir5.setEdificio("Horizontes")
dir5.setApto("20-03")

user5.setFecha(fecha5)
user5.setDir(dir5)
user5.setCiudad("Manizales")
user5.setTel(3208765432)
user5.setEmail("luisa_bonita@gmail.com")

# Lab 6
agenda1 = Agenda(5)

agenda1.agregar(user1)
agenda1.agregar(user2)
agenda1.agregar(user3)
agenda1.agregar(user4)
agenda1.agregar(user5)

agenda1.mostar()
agenda1.toFile("agenda1.txt")

print("Agenda 2")
agenda2 = Agenda(5)
agenda2.importText("agenda1.txt")
agenda2.mostar()
agenda2.eliminar(73810)
agenda2.toFile("agenda2.txt")
