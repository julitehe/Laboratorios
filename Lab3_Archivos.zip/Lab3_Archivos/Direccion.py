class Direccion:
    # constructor
    def __init__(self):
        # atributos
        self.__calle = None
        self.__nomenclatura = None
        self.__barrio = None
        self.__ciudad = None
        self.__edificio = None
        self.__apto = None

    # settings
    def setCalle(self, c):
        self.__calle = c
    def setNomenclatura(self, n):
        self.__nomenclatura = n
    def setBarrio(self, b):
        self.__barrio = b
    def setCiudad(self, ci):
        self.__ciudad = ci
    def setEdificio(self, e):
        self.__edificio = e
    def setApto(self, a):
        self.__apto = a

    # gettings
    def getCalle(self):
        return self.__calle
    def getNomenclatura(self):
        return self.__nomenclatura
    def getBarrio(self):
        return self.__barrio
    def getCiudad(self):
        return self.__ciudad
    def getEdificio(self):
        return self.__edificio
    def getApto(self):
        return self.__apto
    
    #to string
    def __str__(self):
        return f"{self.__calle} #{self.__nomenclatura} {self.__barrio}, {
            self.__ciudad}, {self.__edificio}-{self.__apto}"
    