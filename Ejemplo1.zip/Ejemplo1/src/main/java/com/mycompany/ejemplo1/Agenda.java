/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author julia
 */
public class Agenda {
    
    //atributos
    private int num_reg;
    private Usuario[] registro;
    
    
    //constructor
    public Agenda(int capacidad){
    //crea el array con longitud de capacidad e inicializa con 0
    }
    
    
    //metodos
    public void agregar(Boolean user){
    //buscar() el usuario si ya existe retorna false y no lo crea
    //true si fue posible agregar el nuevo user (lo agrega en la siguiente posicion disponible)
    } 
    public void buscar(int id){
    //busca si hay alguno con ese id retorna -1, en caso contrario retorna el indice 
    } 
    public void eliminar(int id){
    //busca el usuario con el id ingresado, si no encuentra retorna false, si encuentra borrar el usuario y desplaza los siguientes registros y retorna true
    } 
    public void mostrar(){
    //imprime en consola el nombre y el id de todos los usuarios registrados en agenda
    } 
    public void mostrarUsuario(int id){
    //si existe un usuario con ese id muestra toda la info sobre este
    } 
}