/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplo1;
import java.util.Scanner;

/**
 *
 * @author juli
 */
public class Ejemplo1 {
    public static void main(String[] args) {
        // punto A
        Fecha fecha_nac = new Fecha(8,12,2007);
        System.out.println("Mi fecha de nacimiento es: " + fecha_nac);
        
        Direccion mi_dir = new Direccion();
        
        mi_dir.setCalle("Carrera 67");
        mi_dir.setNomenclatura("42-75");
        mi_dir.setBarrio("San Joaquin");
        mi_dir.setCiudad("Medellin");
        mi_dir.setEdificio("Edificio 1");
        mi_dir.setApto("301");
        System.out.println("Mi direcion es: " + mi_dir);
        
        
        System.out.println("");
        Usuario user = new Usuario("Juliana", 1);
        
        user.setFecha_nacimiento(fecha_nac);
        user.setCiudad_nacimiento("Bucaramanga");
        user.setTel(317254898);
        user.setEmail("juliana.teheran@gmail.com");
        user.setDireccion(mi_dir);
        
        System.out.println(user);
        
        //punto B
        Scanner esc = new Scanner(System.in);
        
        Fecha fecha2 = new Fecha();
        System.out.println("Ingrese el dia de nacimiento: ");
        int dia = esc.nextInt();
        fecha2.setDia(dia);
        
        System.out.println("Ingrese el mes de nacimiento: ");
        int mes = esc.nextInt();
        fecha2.setMes(mes);   
        
        System.out.println("Ingrese el año de nacimiento: ");
        int año = esc.nextInt();
        fecha2.setA(año);
        
        esc.nextLine(); // limpiar \n pendiente antes de usar nextLine
        
        Usuario user2 = new Usuario();
        user2.setFecha_nacimiento(fecha2);
        
        Direccion dir2 = new Direccion();
        System.out.println("Ingrese los datos de su direccion. Calle:");
        String cal = esc.nextLine();
        
        System.out.println("Nomenclatura: ");
        String nom = esc.nextLine();
                
        System.out.println("Barrio: ");
        String barrio = esc.nextLine();
        
        System.out.println("Ciudad: ");
        String ciudad = esc.nextLine();
        
        System.out.println("Edificio: ");
        String edificio = esc.nextLine();
        
        System.out.println("Apto: ");
        String apto = esc.nextLine();
        
        
        dir2.setCalle(cal);       
        dir2.setNomenclatura(nom);
        dir2.setBarrio(barrio);
        dir2.setCiudad(ciudad);
        dir2.setEdificio(edificio);
        dir2.setApto(apto);
        
        user2.setDireccion(dir2);
        
        System.out.println("Ingrese sus datos de contacto. Nombre:");
        String nombre = esc.nextLine();
        user2.setNombre(nombre);
        
        System.out.println("Id: ");
        int id = esc.nextInt();
        user2.setId(id);
        
        esc.nextLine(); // limpiar \n antes de ciudad nac
        
        System.out.println("Ciudad nacimiento: ");
        String ciudad_nac = esc.nextLine();
        user2.setCiudad_nacimiento(ciudad_nac);
        
        System.out.println("Telefono: ");
        long tel = esc.nextLong();
        user2.setTel(tel);
        
        esc.nextLine(); // limpiar \n antes de email
        
        System.out.println("Email: ");
        String email = esc.nextLine();
        user2.setEmail(email);
        
        System.out.println(user2);
    }
}
