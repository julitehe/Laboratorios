/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.biblioteca;
import java.util.Scanner;
/**
 *
 * @authors xsraws & juli & majo
 */

public class Biblioteca {
    public static void main(String[] args) {
        Sistema sistema = new Sistema();
        Scanner sc = new Scanner(System.in);
        Menu menu = new Menu(sistema);
        
        
        // Libros existentes
        sistema.agregarLibro("Cálculo: Conceptos y contextos", "James Stewart", "CIE-C-09", 2009, 3);
        sistema.agregarLibro("Álgebra lineal: Una introducción moderna", "David Poole", "CIE-MIN-ALIM-11", 2011, 2);
        sistema.agregarLibro("Macroeconomía", "Olivier Blanchard", "HUM-M-OB-17", 2017, 2);
        sistema.agregarLibro("Arquitectura: forma, espacio y orden", "Francis D. K. Ching", "ARQ-AFEO-15", 2015, 3);
        sistema.agregarLibro("Fundamentos de Física", "David Halliday, Robert Resnick, Jearl Walker", "CIE-FIS-FDF-14", 2014, 2);
        
        sistema.agregarUsuario("Admin Juliana", "admi123");
        sistema.agregarUsuario("Profe Sara", "profe123");
        sistema.agregarUsuario("Maria Jose", "estu123");
        sistema.agregarUsuario("Admon Julio","admon123");
        
        String nombre;
        String cont;
        boolean condicion;
        
        System.out.println("Ingresa tu usuario: ");
        nombre = sc.nextLine();
        System.out.println("Ingresa tu contraseña:");
        cont = sc.nextLine();
        
        condicion = sistema.logIn(nombre, cont) != 0 && sistema.logIn(nombre, cont) != 1;
        while(condicion){
            System.out.println("Datos incorrectos");
            System.out.println("Ingresa tu usuario: ");
            nombre = sc.nextLine();
            System.out.println("Ingresa tu contraseña:");
            cont = sc.nextLine();
            condicion = sistema.logIn(nombre, cont) != 0 && sistema.logIn(nombre, cont) != 1;        
        }

        System.out.println("Bienvenido al sistema de biblioteca :D");
        
        switch (sistema.logIn(nombre, cont)) {
            case -1:
                System.exit(0);
            case 0:
                menu.menuAdmin(nombre);
                break;
            default:
                menu.menuOtros(nombre);
                break;
        }
    }
}
