/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;
import java.util.Scanner;

/**
 *
 * @author xsraws
 */
public class Menu {
    private final Sistema sistema;
    private final Scanner sc = new Scanner(System.in);
    
    public Menu(Sistema sis){
        this.sistema = sis;}
    
    public void menuAdmin(String nombre){
        int opcion = -1;
        while(opcion != 0){
            System.out.println("Seleccione una opción:");
            System.out.println("0. Salir");
            System.out.println("1. Libros");
            System.out.println("2. Usuarios");
            opcion = sc.nextInt();
            sc.nextLine();
            
            switch(opcion){
                case 1 -> accionesLibros(0, nombre);
                case 2 -> accionesUsuarios(0, nombre);

            }
        }
    }
    
    public void menuOtros(String nombre){
        int opcion = 1;
        while(opcion != 0){
            System.out.println("Seleccione una opción:");
            System.out.println("0. Salir");
            System.out.println("1. Libros");
            System.out.println("2. Mi perfil");
            opcion = sc.nextInt();
            sc.nextLine();
        
            switch(opcion){
                case 1 -> accionesLibros(1, nombre);
                case 2 -> accionesUsuarios(1, nombre);
            }
        }
    }
    // mostrar las acciones para libros
    public void accionesLibros(int identificador, String nombre){
        int accion;
 
        System.out.println("Seleccione una acción");
        if(identificador == 0){
            System.out.println("0. Salir\n1. Buscar libro\n2. Agregar libro\n3. Editar libro\n4. Eliminar libro\n5. Pedir prestado\n6. Devolver libro\n7. Ver todos los libros\n8. Ver libros prestados");
            accion = sc.nextInt();
            sc.nextLine();
            accionesLibrosAdmin(accion, nombre);
        }
        else{
            System.out.println("0. Salir\n1. Buscar libro\n2. Pedir prestado\n3. Devolver libro\n4. Ver libros prestados");
            accion = sc.nextInt();
            sc.nextLine();
            accionesLibrosUsuario(accion, nombre);
        }
    }
    
    // mostrar acciones para usuarios
    public void accionesUsuarios(int identificador, String nombre){
        int accion;

        System.out.println("Seleccione una acción");
        if(identificador == 0){
            System.out.println("0. Salir\n1. Buscar usuario\n2. Agregar usuario\n3. Editar usuario\n4. Eliminar usuario\n5. Ver todos los usuarios");
            accion = sc.nextInt();
            sc.nextLine();
            accionesUsuariosAdmin(accion);
        }
        else{
            System.out.println("0. Salir\n1. Cambiar nombre\n2. Cambiar contraseña");
            accion = sc.nextInt();
            sc.nextLine();
            accionesPerfil(accion);
        }  
    }
    
    // acciones sobre libros que realiza el admin
    public void accionesLibrosAdmin(int accion, String nombre){
        String cod;
        switch(accion){
            case 0 -> {
                System.exit(0);                
            }
            case 1 -> {
                //buscar
                System.out.println("Código: ");
                cod = sc.nextLine();
                sistema.mostrarLibro(sistema.buscarLibro(cod.toUpperCase()));
            }
            case 2 -> {
                // agregar libro
                System.out.println("Título: ");
                String titulo = sc.nextLine();
                System.out.println("Autor: ");
                String autor = sc.nextLine();
                System.out.println("Código: ");
                cod = sc.nextLine();
                System.out.println("Año de publicación: ");
                int añoPu = sc.nextInt();
                sc.nextLine();
                System.out.println("Número de ejemplares: ");
                int numEj = sc.nextInt();
                sistema.agregarLibro(titulo, autor, cod.toUpperCase(), añoPu, numEj);
                System.out.println("Libro agregado correctamente: " + titulo );
            }
            case 3 -> {
                // editar libro
                System.out.println("Código: ");
                cod = sc.nextLine();
                System.out.println("Campo a cambiar: ");
                String campo = sc.nextLine();
                System.out.println("Nuevo valor: ");
                String nuevo = sc.nextLine();
                sistema.editarLibro(cod.toUpperCase(), campo, nuevo);
            }
            case 4 -> {
                // eliminar
                System.out.println("Código: ");
                cod = sc.nextLine();
                sistema.eliminarLibro(cod.toUpperCase());
                System.out.println("Libro eliminado correctamente");
            }
            case 5 -> {
                // pedir prestado
                System.out.println("Confirme su usuario: ");
                nombre = sc.nextLine();                
                System.out.println("Código del libro solicitado: ");
                cod = sc.nextLine();
                sistema.pedirPrestado(nombre, cod.toUpperCase());
            }
            case 6 -> {
                //devolver
                System.out.println("Confirme su usuario: ");
                nombre = sc.nextLine();                
                System.out.println("Código del libro para devolver: ");
                cod = sc.nextLine();
                sistema.devolver(nombre, cod.toUpperCase());
            }
            case 7 -> // mostrar todos los libros
                sistema.mostrarLibros();
            case 8 -> // mostrar libros 
                sistema.mostrarLibrosPrestados();
            
        }
    }
    
    // acciones sobre libros que realizan estudiantes y profesores
    public void accionesLibrosUsuario(int accion, String nombre){
        String cod;
        switch(accion){
            case 0 -> {
                System.exit(0);
            }
            case 1 -> {
                //buscar
                System.out.println("Código: ");
                cod = sc.nextLine();
                sistema.mostrarLibro(sistema.buscarLibro(cod.toUpperCase()));
            }
            case 2 -> {
                //pedir prestado
                System.out.println("Confirme su usuario: ");
                nombre = sc.nextLine();
                System.out.println("Código del libro solicitado: ");
                cod = sc.nextLine();
                sistema.pedirPrestado(nombre, cod.toUpperCase());
            }
            case 3 -> {
                // devolver libro
                System.out.println("Confirme su usuario: ");
                nombre = sc.nextLine();
                System.out.println("Código del libro para devolver: ");
                cod = sc.nextLine();
                sistema.devolver(nombre, cod.toUpperCase());
            }
            case 4 -> {
                // ver mis libros prestados
                System.out.println("Confirme su usuario: ");
                nombre = sc.nextLine();
                System.out.println(sistema.mostrarPrestadosUsuario(nombre)); 
            }
                
        }
    }        
    
    // acciones sobre usuarios que realiza el admin
    public void accionesUsuariosAdmin(int accion){
        String nom;
        switch(accion){
            case 0 -> {
                System.exit(0);
            }

            case 1 -> {
                //buscar
                System.out.println("Nombre: ");
                nom = sc.nextLine();
                sistema.mostrarUsuario(sistema.buscarUsuario(nom));
            }
            case 2 -> {
                // agregar usuario
                System.out.println("Nombre: ");
                nom = sc.nextLine();
                System.out.println("Contraseña: ");
                String cont = sc.nextLine();
                sistema.agregarUsuario(nom, cont);
                System.out.println("Usuario agregado correctamente: " + nom);
            }
            case 3 -> {
                // editar nombre
                System.out.println("Nombre actual: ");
                nom = sc.nextLine();
                System.out.println("Nuevo nombre: ");
                String nuevo = sc.nextLine();
                sistema.editarUsuario(nom, "nombre", nom, nuevo);
            }
            case 4 -> {
                System.out.println("Nombre: ");
                nom = sc.nextLine();
                sistema.eliminarUsuario(nom);
                System.out.println("Usuario eliminado correctamente: " + nom);
            }
            case 5 -> sistema.mostrarUsuarios();

        }
    }
    
    // acciones sobre usuario que realizan estudiantes y profesores
    public void accionesPerfil(int accion){
        String nom;
        String nuevo;
        switch(accion){
            case 0 -> {
                System.exit(0);                
            }
            case 1 -> {
                // cambiar nombre
                System.out.println("Nombre actual: ");
                nom = sc.nextLine();
                System.out.println("Nuevo nombre: ");
                nuevo = sc.nextLine();
                sistema.editarUsuario(nom, "nombre", nom, nuevo);
            }
            case 2 -> { 
                System.out.println("Nombre: ");
                nom = sc.nextLine();
                System.out.println("Contraseña actual: ");
                String actual = sc.nextLine();
                System.out.println("Nueva contraseña nombre: ");
                nuevo = sc.nextLine();
                sistema.editarUsuario(nom, "contraseña", actual, nuevo);
            }
        }
    }
}
