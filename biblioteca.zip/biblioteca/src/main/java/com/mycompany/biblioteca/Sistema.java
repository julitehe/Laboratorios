/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author xsraws
 */
public class Sistema {
    private int numLibros = 0;
    private int numUsuarios = 0; 
    private Libro[] libros = new Libro[20];
    private Usuario[] usuarios = new Usuario[20];
    
    public Sistema(){}
    
    public int getNumLibros(){
        return numLibros;}
    
    public int getNumUsuarios(){
        return numUsuarios;}
    
    public void setNumLibros(int n){
        this.numLibros = n;}
    
    public void setNumUsuarios(int u){
        this.numUsuarios = u;}
    
    // Verifica que el usuario existe y si su contraseña coincide
    public int logIn(String nombre, String contr){
        int idxU = buscarUsuario(nombre);
        if(idxU == -1){
            return -1;}
        if(!usuarios[idxU].getContraseña().equals(contr)){
            return -1;}
        
        if(usuarios[idxU].getNombre().startsWith("Admin")){
            return 0;}
        return 1;
    }
    
    public void agregarLibro(String t, String au, String cod, int ap, int numEj){
        Libro nuevo = new Libro(t, au, cod, ap, numEj);
        libros[numLibros] = nuevo;
        libros[numLibros].setNumDisponibles(numEj);
        numLibros++;
    }
    
    public int buscarLibro(String cod){
        for(int i = 0; i < numLibros; i++){
            if(libros[i].getCodigo().equals(cod)){
                return i;}
        }
        System.out.println("El libro no se encontró en la biblioteca");
        return -1;
    }
    
    public void editarLibro(String cod, String campo, String nuevoValor){
        int index = buscarLibro(cod);
        
        campo = campo.toLowerCase();
        
        switch(campo){
            case "titulo" -> libros[index].setTitulo(nuevoValor);
            case "autor" -> libros[index].setAutor(nuevoValor);
            case "codigo" -> libros[index].setCodigo(nuevoValor);
            default -> {
                System.out.println("El campo no fue encontrado");
                return;
            }
            }
        System.out.println("Libro actualizado\n"+ libros[index].toString());
    }
    
    public void eliminarLibro(String cod){
        int index = buscarLibro(cod);
        for(int i = index + 1; i < libros.length ; i++ ){
            libros[i-1] = libros[i];}
        numLibros--;
    }
    
    public void mostrarLibro(int idx){
        if(idx==-1){return;}
        System.out.println(libros[idx].toString());}
    
    public void mostrarLibros(){
        for(int i = 0; i < numLibros; i++){
            System.out.println(libros[i].toString());
        }
    }
    
    public String mostrarPrestadosUsuario(String nombre){
        return usuarios[buscarUsuario(nombre)].verLibrosPrestados();
    }
    
    public void mostrarLibrosPrestados(){
        System.out.println("-------- Todos los libros prestados: --------");
        for(int n = 0; n < numUsuarios; n++){
            if (usuarios[n].getNumLibrosPrestados() == 0){
                System.out.println("Libros prestados a " + usuarios[n].getNombre() + ": 0");
            }
            else{
                usuarios[n].verLibrosPrestados();
            }
        }
    }
    
    public int buscarUsuario(String nom){
        for(int n = 0; n < numUsuarios; n++){
            if(usuarios[n].getNombre().equals(nom)){
                return n;}
        }
        return -1;
    }
    
     public void agregarUsuario(String nom, String cont){
        Usuario nuevo = new Usuario(nom, cont);
        usuarios[numUsuarios] = nuevo;
        numUsuarios++;
    }
     
    public void editarUsuario(String nombre, String campo, String actual, String nuevoValor){
        int idx = buscarUsuario(nombre);
        if(idx == -1){return;}
        
        switch(campo){
            case "nombre" -> usuarios[idx].setNombre(nuevoValor);
            case "contraseña" -> usuarios[idx].cambiarContraseña(actual, nuevoValor);
        }
        System.out.println("Usuario actualizado \n" + usuarios[idx].toString());
    }
    
    public void eliminarUsuario(String nom){
        int index = buscarUsuario(nom);
        
        if(index == -1){
            return;}
        
        for(int i = index+1; i < usuarios.length; i++){
            usuarios[i-1] = usuarios[i];
        }
        numUsuarios--;
    }
   
    public void mostrarUsuario(int idx){
        System.out.println(usuarios[idx].toString());}
    
    public void mostrarUsuarios(){
        for(int i = 0; i < numUsuarios; i++){
           System.out.println(usuarios[i].toString());
        }
    }
    
    public boolean pedirPrestado(String nombre, String cod){
        int idxL = buscarLibro(cod);
        int idxU = buscarUsuario(nombre);
        if (idxL == -1 || idxU == -1){
            System.out.println("El usuario o el libro son incorrectos");
            return false;
        }
        
        Libro libro = libros[idxL]; 
        Usuario user = usuarios[idxU];
        
        int numLP = user.getNumLibrosPrestados();

              
        if (libro.getNumDisponibles()== 0){
            System.out.println("En este momento, no hay ejemplares disponibles :(");
            return false;
        }

        if (user.getLibrosMax() == user.getNumLibrosPrestados()){
            System.out.println("Ya no puedes pedir más libros :O");
            return false;
        }

        for(int i = 0; i < numLP; i++){
            if(user.getLibroPrestadoEn(i).getCodigo().equals(libro.getCodigo())){
                System.out.println("Ya has pedido prestado un ejemplar de este libro :/");
                return false;
            }    
        }
        user.agregarLibrosPrestados(libro);
        libro.setNumDisponibles(libro.getNumDisponibles() - 1);
        System.out.println("Prestamo realizado correctamente :D");
        return true;                                
    }
    
    public boolean devolver(String nombre, String cod){
        int idxL= buscarLibro(cod);
        int idxU = buscarUsuario(nombre);
        if (idxL == -1 || idxU == -1){
            System.out.println("El usuario o el libro son incorrectos");
            return false;
        }
        Libro libro = libros[idxL];
        
        Usuario user = usuarios[idxU];
        int numLP = user.getNumLibrosPrestados();
        
        
        
        for(int i = 0; i < numLP ; i++){ 
            if (user.getLibroPrestadoEn(i).getCodigo().equals(libro.getCodigo())){
                libro.setNumDisponibles(libro.getNumDisponibles() + 1 ); //Añadir uno a numDisponibles
                user.eliminarLibroPrestadoEn(i);
                System.out.println("Libro devuelto correctamente :D");
                return true;                    
            }
        }
        System.out.println("Este libro no se encontró en tu lista de libros prestados :(");
        return false;            
    }
    
}
