/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.laboratorio1;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author beastkeeper
 */
public class Laboratorio1 {

    public static void main(String[] args) {
        // Lee el input del usuario para la longitud del arreglo, y vuelve a preguntar si el número es menor que 0 o mayor que 12
        Scanner escaner = new Scanner(System.in);
        System.out.println("Ingresa el tamaño del arreglo A: ");
        int tamaño = escaner.nextInt();
        while ((tamaño > 12) || (tamaño <= 0)){
            System.out.println("Por favor ingresa un número entero menor o igual a 12: ");
            tamaño = escaner.nextInt();
        }
        
        // Corre un ciclo para pedir cada valor de arreglo A
        int[] arregloA = new int[tamaño];
        for(int i = 0; i < tamaño; i++) {
            System.out.println("Ingresa el valor #"+(i+1)+" del arreglo A");
            int elemento = escaner.nextInt();
            arregloA[i] = elemento;
        }
        System.out.println("Areglo A: "+Arrays.toString(arregloA)); // Imprime el arreglo A
        
        // Genera e imprime el arreglo B
        Random numAleatorio = new Random();
        int[] arregloB = new int[tamaño];
        for(int j = 0; j < tamaño; j++){
            arregloB[j] = numAleatorio.nextInt(20) + 1;
            }
        System.out.println("Areglo B: "+Arrays.toString(arregloB));
        
        // Suma de los arreglos A y B
        int[] suma_AB = new int[tamaño];
        for (int k  = 0; k < tamaño; k++) {
            suma_AB[k] = arregloA[k] + arregloB[k];
        }
        System.out.println("Suma de A y B: "+Arrays.toString(suma_AB));
        
        // Producto de los arreglos A y B
        int[] prod_AB = new int[tamaño];
        for (int m  = 0; m < tamaño; m++) {
            prod_AB[m] = arregloA[m] * arregloB[m];
        }
        System.out.println("Producto de A y B: "+Arrays.toString(prod_AB));
        
        // SUMA DE TODOS LOS PARES EN ARREGLO A
        int sum_arrA = 0;
        for (int n = 0; n < tamaño; n++) {
            if(arregloA[n] % 2 == 0) {
            sum_arrA = sum_arrA + arregloA[n];
            }
        }
        System.out.println("Suma de todos los pares en el arreglo A: "+sum_arrA);
        
        // PROMEDIO ARREGLO B
        
        int sum_arrB = 0;
        for (int n = 0; n < tamaño; n++) {
            sum_arrB = sum_arrB + arregloB[n];
        }
        float promedio = sum_arrB / tamaño;
        System.out.println("Promedio de todos los números en el arreglo B: "+promedio);
        
        
        // Generación arreglo C
        int[] arregloC = new int[tamaño *2]; // Se especifica el tamaño desde el inicio
        int indice = 0;
        for (int w = 0; w < tamaño; w++) {
            arregloC[indice++] = arregloA[w]; // indice++ funciona de esta forma: Lee el valor inicial y después le añade 1. En este caso lo lee como 0 e incrementa 1.
            arregloC[indice++] = arregloB[w];
        }
        System.out.println("Arreglo C :" +Arrays.toString(arregloC));
        
        // Valor máximo y su posición en C
        int maximo = arregloC[0];
        int pos = 0;
        for(int l = 1; l < tamaño; l++) {
            if (arregloC[l] > maximo) {
                maximo = arregloC[l];
                pos = l;
            }
        }
        System.out.println("El valor más grande del arreglo C es " +maximo+" en la posición "+pos);
    }
}
