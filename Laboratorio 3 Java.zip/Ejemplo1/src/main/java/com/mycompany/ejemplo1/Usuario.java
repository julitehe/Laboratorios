/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author juli
 */
public class Usuario {
    
    //Atributos
    private String nombre;
    private long id;
    private Fecha fecha_nacimiento;
    private String ciudad_nacimiento;        
    private long tel;
    private String email;
    private Direccion dir;
    
    //Constructores
    public Usuario(){}
    public Usuario(String n, long id){
        this.nombre = n;
        this.id = id;
    }
    
    //Metodos: Set y Get :)
    public void setNombre(String n){this.nombre=n;}
    public void setId(long id){this.id=id;}
    public void setFecha_nacimiento(Fecha f){this.fecha_nacimiento=f;}
    public void setCiudad_nacimiento(String c){this.ciudad_nacimiento=c;}
    public void setTel(long t){this.tel=t;}
    public void setEmail(String e){this.email=e;}
    public void setDireccion(Direccion d){this.dir=d;}
    
    public String getNombre(){return nombre;}
    public long getId(){return id;}
    public Fecha getFecha_nacimiento(){return fecha_nacimiento;}
    public String getCiudad_nacimiento(){return ciudad_nacimiento;}
    public long getTel(){return tel;}
    public Direccion getDireccion(){return dir;}
    public String getEmail(){return email;}
    @Override
    public String toString(){
        return "Nombre: " + nombre + " Id: " + id + "\nTelefono: " + tel + " Email: " + email + "\nNacimiento: " + fecha_nacimiento + " " + ciudad_nacimiento + "\nDireccion: " + dir + "\n";}
}
