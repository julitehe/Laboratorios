/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejemplo1;
import java.util.Scanner;

/**
 *
 * @author juli
 */
public class Ejemplo1 {
    public static void main(String[] args) {
        //============== USER 1 ===================
        Fecha fecha_nac1 = new Fecha(8, 12, 2007);
        
        Direccion mi_dir1 = new Direccion();
        mi_dir1.setCalle("Carrera 67");
        mi_dir1.setNomenclatura("42-75");
        mi_dir1.setBarrio("San Joaquin");
        mi_dir1.setCiudad("Medellin");
        mi_dir1.setEdificio("Edificio 1");
        mi_dir1.setApto("301");

        Usuario user1 = new Usuario("Juliana", 1);
        
        user1.setFecha_nacimiento(fecha_nac1);
        user1.setCiudad_nacimiento("Bucaramanga");
        user1.setTel(317254898);
        user1.setEmail("juliana.teheran@gmail.com");
        user1.setDireccion(mi_dir1);
                
        // ==================== USER 2 ====================
        Fecha fecha_nac2 = new Fecha(15, 5, 2005);

        Direccion mi_dir2 = new Direccion();
        mi_dir2.setCalle("Calle 23");
        mi_dir2.setNomenclatura("10-45");
        mi_dir2.setBarrio("El Poblado");
        mi_dir2.setCiudad("Medellin");
        mi_dir2.setEdificio("Torre Verde");
        mi_dir2.setApto("502");

        Usuario user2 = new Usuario("Santiago", 2);
        user2.setFecha_nacimiento(fecha_nac2);
        user2.setCiudad_nacimiento("Pereira");
        user2.setTel(310567890);
        user2.setEmail("santiago.vargas@gmail.com");
        user2.setDireccion(mi_dir2);

        // ==================== USER 3 ====================
        Fecha fecha_nac3 = new Fecha(21, 3, 2008);

        Direccion mi_dir3 = new Direccion();
        mi_dir3.setCalle("Carrera 50");
        mi_dir3.setNomenclatura("15-60");
        mi_dir3.setBarrio("Chapinero");
        mi_dir3.setCiudad("Bogota");
        mi_dir3.setEdificio("Residencias Sol");
        mi_dir3.setApto("101");

        Usuario user3 = new Usuario("Valentina", 3);
        user3.setFecha_nacimiento(fecha_nac3);
        user3.setCiudad_nacimiento("Bogota");
        user3.setTel(320888555);
        user3.setEmail("valentina.rodriguez@gmail.com");
        user3.setDireccion(mi_dir3);

        // ==================== USER 4 ====================
        Fecha fecha_nac4 = new Fecha(2, 11, 2006);

        Direccion mi_dir4 = new Direccion();
        mi_dir4.setCalle("Avenida 30");
        mi_dir4.setNomenclatura("85-22");
        mi_dir4.setBarrio("Centro");
        mi_dir4.setCiudad("Cali");
        mi_dir4.setEdificio("Plaza Real");
        mi_dir4.setApto("702");

        Usuario user4 = new Usuario("Andres", 4);
        user4.setFecha_nacimiento(fecha_nac4);
        user4.setCiudad_nacimiento("Cali");
        user4.setTel(301999777);
        user4.setEmail("andres.martinez@gmail.com");
        user4.setDireccion(mi_dir4);

        // ==================== USER 5 ====================
        Fecha fecha_nac5 = new Fecha(30, 7, 2009);

        Direccion mi_dir5 = new Direccion();
        mi_dir5.setCalle("Transversal 12");
        mi_dir5.setNomenclatura("55-19");
        mi_dir5.setBarrio("La Flora");
        mi_dir5.setCiudad("Barranquilla");
        mi_dir5.setEdificio("Mirador del Mar");
        mi_dir5.setApto("403");

        Usuario user5 = new Usuario("Camila", 5);
        user5.setFecha_nacimiento(fecha_nac5);
        user5.setCiudad_nacimiento("Barranquilla");
        user5.setTel(304123456);
        user5.setEmail("camila.fernandez@gmail.com");
        user5.setDireccion(mi_dir5);
        
        Scanner esc = new Scanner(System.in);
        System.out.println("Ingrese la capacidad de la agenda:");
        int capacidad = esc.nextInt();
        Agenda agenda = new Agenda(capacidad);
        
        //Agregar 5 usuarios a la agenda
        agenda.agregar(user1);
        agenda.agregar(user2);
        agenda.agregar(user3);
        agenda.agregar(user4);
        agenda.agregar(user5);
        
        //Mostrar todos los usuarios
        agenda.mostrar();
        
        //Mostrar toda la informacion de 2 usuarios
        agenda.mostrarUsuario((int) user3.getId());
        agenda.mostrarUsuario((int) user4.getId());

        agenda.eliminar((int) user5.getId());
        agenda.eliminar((int) user2.getId());
        agenda.mostrar();
    }
}
