/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author julia
 */
public class Agenda {
    
    //atributos
    private int num_reg;
    private final Usuario registro[];
    
    //constructor
    public Agenda(int capacidad){
        registro = new Usuario[capacidad];
        num_reg = 0;
    }
    
    //metodos
    public boolean agregar(Usuario user){
        if(buscar((int) user.getId()) >= 0 ){
            System.out.println("Este usuario ya esta en agenda");
            return false;
        }else{
            
            registro[num_reg] = user; 
            num_reg ++;
            System.out.println("Usuario agregado correctamente");
            return true;
        }
    }
     
    public int buscar(int id){
        if (num_reg == 0){
            System.out.println("Agenda vacia");
            return -1;} 
        for(int i = 0; i < num_reg ; i ++){if(registro[i].getId() == id){return i;}}
        return -1;}

    public Boolean eliminar(int id){
        int indiceUser = buscar(id);
        if(indiceUser < 0){
            System.out.println("Usuario no está en agenda");
            return false;
        }
        else{
            if (indiceUser != registro.length){
                for(int j = (indiceUser + 1) ; j < registro.length ; j++){
                    registro[j-1] = registro[j];
                }
                num_reg -= 1;            
                System.out.println("El usuario ha sido eliminado correctamente.");
                return true;
            }
            else{
                return false;
            }
        }
    } 
    
    public void mostrar() {
        if (num_reg == 0){System.out.println("Agenda esta vacia");}
        else{
            System.out.println("\nInformacion todos los usuarios:");
            for(int i = 0; i < num_reg; i++){
                System.out.println("Usuario #" + (i + 1));
                System.out.println("Nombre: " + registro[i].getNombre() + " - Id: " + registro[i].getId()+ "\n");
            }}
    }

    public void mostrarUsuario(int id){
        int indiceUser = buscar(id);
        if(indiceUser < 0){
            System.out.println("El ID ingresado no está en la agenda");
        }
        else{
            System.out.println("Informacion usuario " +  registro[buscar(id)].getNombre() + ":\n");
            System.out.println(registro[indiceUser]);}
    }}