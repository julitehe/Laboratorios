/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.ejemplo1;

/**
 *
 * @author juli
 */
public class Direccion {
    
    //Atributos
    private String calle;
    private String nomenclatura;
    private String barrio;
    private String ciudad;
    private String edificio;
    private String apto;
    
    //Constructor 
    public Direccion(){}
    
    //Metodos set y get :)
    public void setCalle(String c){this.calle = c;}
    public void setNomenclatura(String n){this.nomenclatura = n;}
    public void setBarrio(String b){this.barrio = b;}
    public void setCiudad(String ci){this.ciudad = ci;}
    public void setEdificio(String e){this.edificio = e;}
    public void setApto(String a){this.apto = a;}
    
    public String getCalle(){return calle;}
    public String getNomenclatura(){return nomenclatura;}
    public String getBarrio(){return barrio;}
    public String getCiudad(){return ciudad;}
    public String getEdificio(){return edificio;}
    public String getApto(){return apto;}
    @Override 
    public String toString(){return calle + " " + "#" + nomenclatura + " " + barrio + ", " + ciudad + ". " + edificio + "-" + apto;}
}
