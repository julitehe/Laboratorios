package com.mycompany.lab5interfaces;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author beastkeeper
 */
public class Circulo implements Shape {
    private double radio;
    double pi = 3.14;
    //
    public Circulo(double r){
        this.radio = r;
    }
    //
    @Override
    public double calcularArea(){
        double area = pi*(radio*radio); 
        return area;
    }
    public double calcularPerimetro(){
        double perimetro = (2*pi*radio);
        return perimetro;
    }
    public String toString(){
        return "Área: " + calcularArea() + " // "+ "Perímetro: " + calcularPerimetro() + "\n" ;}
}