package com.mycompany.lab5interfaces;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author beastkeeper
 */
public interface Shape {
    
    double calcularArea();
    double calcularPerimetro();
    
}
