package com.mycompany.lab5interfaces;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author beastkeeper
 */
public class Triangulo implements Shape {
    private double base;
    private double altura;
    //
    public Triangulo(double b, double a){
        this.base = b;
        this.altura = a;
    }
    //
    @Override
    public double calcularArea(){
        double area = (base*altura)/2;
        return area;
    }
    public double calcularPerimetro(){
        double perimetro = (base*3); // Asumiendo el triángulo como equilátero
        return perimetro;
    }
    public String toString(){
        return "Área: " + calcularArea() +" (NOTA: Se asume el triángulo como equilátero). // "+ "Perímetro: " + calcularPerimetro() + "\n" ;}
}
