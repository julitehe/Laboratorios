package com.mycompany.lab5interfaces;
/**
 *
 * @author beastkeeper
 */
public class Main {
    public static void main(String[] args) {
        
     Circulo rad2 = new Circulo(2);
     Rectangulo re510 = new Rectangulo(5,10);
     Triangulo tr23 = new Triangulo(2,3);
     
     System.out.println("Círculo de radio 2: " + "\n" + rad2);
     System.out.println("Rectángulo ancho 5, altura 10: "+ "\n"+ re510);
     System.out.println("Triángulo base 2 altura 3: "+ "\n"+ tr23);
    }
}
