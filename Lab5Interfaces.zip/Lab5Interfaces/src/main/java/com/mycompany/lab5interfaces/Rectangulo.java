package com.mycompany.lab5interfaces;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author beastkeeper
 */
public class Rectangulo implements Shape {
    private double base;
    private double altura;
    //
    public Rectangulo(double b, double a){
        this.base = b;
        this.altura = a;
    }
    //
    @Override
    public double calcularArea(){
        double area = base*altura;
        return area;
    }
    public double calcularPerimetro(){
        double perimetro = (base*2 + altura*2);
        return perimetro;
    }
    public String toString(){
        return "Área: " + calcularArea() + " // " + "Perímetro: " + calcularPerimetro() + "\n" ;}
}
