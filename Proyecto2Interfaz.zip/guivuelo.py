### TO-DO ####
# Implementar codigo de login / registro
# 
#
#############
# Paleta de colores:
# Fondo #2B2F42
# Blanco #EFEFEF
# Azul #3454D1
# Turquesa #34D1BF
#############
import customtkinter
from customtkinter import CTk, CTkFrame, CTkLabel, CTkEntry, CTkButton, CTkImage, CTkToplevel, CTkRadioButton
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk
import os
import random
import string
import json

customtkinter.set_appearance_mode('dark')

USERS_FILE = "usuarios.txt"
FLIGHTS_FILE = "vuelos.txt"
RESERVATIONS_FILE = "reservas.txt"

# precios por defecto
PRICE_PREF = 850000
PRICE_ECO = 235000
CABIN_EXTRA_ECO = 40000
HOLD_EXTRA_PREF = 50000
HOLD_EXTRA_ECO = 80000
MILLAS_POR_RESERVA = 500
MILLAS_CANJE_PREFERENCIAL = 2000

def load_users():
    users = {}
    if not os.path.exists(USERS_FILE):
        return users
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # intentar primero con tabulador, si no con whitespace
            parts = line.split("\t") if "\t" in line else line.split()
            # formato esperado: Nombre\tContraseña\tDocumento\tCorreo\tTelefono
            if len(parts) >= 5:
                name = parts[0]
                password = parts[1]
                doc = parts[2]
                email = parts[3]
                phone = parts[4]
                users[doc] = {'name': name, 'password': password, 'email': email, 'phone': phone}
    return users

def save_user(user):
    # append new user (usa tab como separador)
    os.makedirs(os.path.dirname(USERS_FILE) or ".", exist_ok=True)
    with open(USERS_FILE, "a", encoding="utf-8") as f:
        f.write(f"{user['name']}\t{user['password']}\t{user['doc']}\t{user.get('email','')}\t{user.get('phone','')}\n")

def load_flights():
    flights = []
    if not os.path.exists(FLIGHTS_FILE):
        return flights
    with open(FLIGHTS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split()
            # Se espera: codigo origen destino dia hora sillas_pref sillas_eco
            if len(parts) >= 7:
                code = parts[0]
                origen = parts[1].capitalize()
                destino = parts[2].capitalize()
                dia = parts[3].upper()
                hora = parts[4]
                try:
                    sillas_pref = int(parts[5])
                    sillas_eco = int(parts[6])
                except Exception:
                    sillas_pref = 0
                    sillas_eco = 0
                flights.append({
                    'code': code,
                    'origen': origen,
                    'destino': destino,
                    'dia': dia,
                    'hora': hora,
                    'sillas_pref': sillas_pref,
                    'sillas_eco': sillas_eco,
                    'price_pref': PRICE_PREF,
                    'price_eco': PRICE_ECO,
                })
    return flights

def save_flights(flights):
    with open(FLIGHTS_FILE, "w", encoding="utf-8") as f:
        for fl in flights:
            f.write(f"{fl['code']}\t{fl['origen']}\t{fl['destino']}\t{fl['dia']}\t{fl['hora']}\t{fl['sillas_pref']}\t{fl['sillas_eco']}\n")

def load_reservations():
    # formato por fila (CSV con tab): reserva_id\tuser_doc\tflight_code\tpref\teco\tmaletas_cabina\tmaletas_bodega\ttotal
    res = []
    if not os.path.exists(RESERVATIONS_FILE):
        return res
    with open(RESERVATIONS_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split("\t") if "\t" in line else line.split()
            # asegurar al menos 8 campos, si faltan rellenar con defaults
            if len(parts) < 8:
                # intentar ignorar líneas malformadas
                continue
            try:
                res.append({
                    'id': parts[0],
                    'user_doc': parts[1],
                    'flight_code': parts[2],
                    'pref': int(parts[3]) if parts[3].isdigit() else 0,
                    'eco': int(parts[4]) if parts[4].isdigit() else 0,
                    'maletas_cabina': int(parts[5]) if parts[5].isdigit() else 0,
                    'maletas_bodega': int(parts[6]) if parts[6].isdigit() else 0,
                    'total': float(parts[7]) if parts[7].replace('.','',1).isdigit() else 0.0
                })
            except Exception:
                # ignorar línea si no se puede parsear
                continue
    return res

def save_reservations(reservations):
    os.makedirs(os.path.dirname(RESERVATIONS_FILE) or ".", exist_ok=True)
    with open(RESERVATIONS_FILE, "w", encoding="utf-8") as f:
        for r in reservations:
            # asegurar keys existentes
            rid = r.get('id','')
            user_doc = r.get('user_doc','')
            flight_code = r.get('flight_code','')
            pref = r.get('pref',0)
            eco = r.get('eco',0)
            cab = r.get('maletas_cabina',0)
            bod = r.get('maletas_bodega',0)
            total = r.get('total',0.0)
            f.write(f"{rid}\t{user_doc}\t{flight_code}\t{pref}\t{eco}\t{cab}\t{bod}\t{total}\n")

def generate_reservation_id():
    return ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))

class LoginVuelos(CTk):
    # messagebox datos incorrectos
    def datos_incorrectos(self):
        messagebox.showerror("Error", "Documento o contraseña incorrectos.")


    # función para que la pantalla aparezca en el centro
    def CenterWindowToDisplay(Screen: CTk, width: int, height: int, scale_factor: float = 1.0):
        screen_width = Screen.winfo_screenwidth()
        screen_height = Screen.winfo_screenheight()
        x = int(((screen_width/2) - (width/2)) * scale_factor)
        y = int(((screen_height/2) - (height/1.5)) * scale_factor)
        return f"{width}x{height}+{x}+{y}"

    def clear_login_form(self):
        try:
            self.id_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        except Exception:
            pass

    def on_register(self):
        self.withdraw()
        if self.ventanaRegistro is None or not self.ventanaRegistro.winfo_exists():
            # pasar self como master para que la ventana de registro pueda volver a quien la abrió
            self.ventanaRegistro = ventanaRegistro(self)
        else:
            self.ventanaRegistro.focus()

    def on_login(self):
        doc = self.id_entry.get().strip()
        pwd = self.password_entry.get().strip()
        users = load_users()
        if doc and doc in users and users[doc]['password'] == pwd:
            # llenar perfil
            self.user_profile = {
                'name': users[doc]['name'],
                'doc': doc,
                'email': users[doc]['email'],
                'millas': getattr(self, 'user_profile', {}).get('millas', 0)
            }
            self.withdraw()
            # decisión admin si nombre inicia por "Admin" (simple)
            if users[doc]['name'].lower().startswith("admin"):
                hub = hubAdmin(self)
                hub.focus()
            else:
                hub = hubUsuario(self)
                hub.focus()
        else:
            self.datos_incorrectos()
    
    def __init__(self):
        super().__init__()
        self.geometry(self.CenterWindowToDisplay(500, 350, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('PLACEHOLDER')
        self.ventanaRegistro = None
        # perfil del usuario (se rellenará desde registro o login)
        self.user_profile = {'name': '', 'doc': '', 'email': '', 'millas': 0}

        # barra de arriba
        top_bar = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar.grid(row=0, column=0, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)

        #logo, titulo y slogan
        self.logo = customtkinter.CTkImage(light_image=Image.open('logo.png'), size=(50,50))
        logo_label = CTkLabel(top_bar, image=self.logo, text="")
        logo_label.grid(row=0, column=0, padx=(8,6), pady=6, sticky="w")

        title_label = CTkLabel(top_bar, text="VUELOS AEROPOLLITO", font=('Verdana', 12, 'bold'), anchor="w")
        title_label.grid(row=0, column=1, sticky="w", padx=(4,0), pady=6)

        slogan = CTkLabel(top_bar, text="Volando contigo!", font=('Serif', 8, 'italic'), anchor="e")
        slogan.grid(row=0, column=2, sticky="e", padx=(0,8), pady=6)
        top_bar.grid_columnconfigure(2, weight=0)

        # contenido principal
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew", padx=20, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Layout inside content
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=1)
        content.grid_columnconfigure(2, weight=1)

        # Texto de bienvenida
        welcome = CTkLabel(content, text="Bienvenido al Sistema Aeropollito!", font=('TkHeadingFont', 14))
        welcome.grid(row=0, column=0, columnspan=3, pady=(6, 14))


        # Usuario
        id_label = CTkLabel(content, text="Documento:", anchor="w")
        id_label.grid(row=1, column=1, sticky="w", padx=5, pady=(0,4))

        self.id_entry = CTkEntry(content, placeholder_text="Documento de identificación", width=300)
        self.id_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=4)

        # Contraseña
        password_label = CTkLabel(content, text="Contraseña:", anchor="w")
        password_label.grid(row=3, column=1, sticky="w", padx=5, pady=(8,4))

        self.password_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=300)
        self.password_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=4)

        # Botones
        register_btn = CTkButton(content, text="Registrarme", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_register)
        register_btn.grid(row=5, column=0, sticky="w", pady=(18,0), padx=8)

        login_btn = CTkButton(content, text="Confirmar", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_login)
        login_btn.grid(row=5, column=2, sticky="e", pady=(18,0), padx=8)


        self.mainloop()

class ventanaRegistro(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 415, 400, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Registro')
        
        top_bar_login = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar_login.grid(row=0, column=0, sticky="ew")
        top_bar_login.grid_columnconfigure(1, weight=1)
        # Botón volver
        volver_btn = CTkButton(top_bar_login, text="Volver", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._volver_a_login)
        volver_btn.grid(row=0, column=0, sticky="w", padx=8, pady=10)
        registrolbl = CTkLabel(top_bar_login, text="Registrar usuario", font=('TkHeadingFont', 16), anchor="e")
        registrolbl.grid(row=0, column=2, padx=10, pady=10, sticky="e")
        top_bar_login.grid_columnconfigure(2, weight=0)

        # Frame de contenido
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, padx=20, pady=(8,12), sticky="nsew")
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Nombre
        nombre_label = CTkLabel(content, text="Nombre:", anchor="w")
        nombre_label.grid(row=0, column=0, sticky="w", pady=(4,2))
        self.nombre_entry = CTkEntry(content, placeholder_text="Nombre completo", width=360)
        self.nombre_entry.grid(row=1, column=0, sticky="ew", pady=(0,8))

        # Correo electrónico
        correo_label = CTkLabel(content, text="Correo electrónico:", anchor="w")
        correo_label.grid(row=2, column=0, sticky="w", pady=(4,2))
        self.correo_entry = CTkEntry(content, placeholder_text="correo@ejemplo.com", width=360)
        self.correo_entry.grid(row=3, column=0, sticky="ew", pady=(0,8))

        # Número de documento
        doc_label = CTkLabel(content, text="Número de documento:", anchor="w")
        doc_label.grid(row=4, column=0, sticky="w", pady=(4,2))
        self.doc_entry = CTkEntry(content, placeholder_text="Número de documento", width=360)
        self.doc_entry.grid(row=5, column=0, sticky="ew", pady=(0,8))

        # Teléfono
        tel_label = CTkLabel(content, text="Teléfono:", anchor="w")
        tel_label.grid(row=6, column=0, sticky="w", pady=(4,2))
        self.tel_entry = CTkEntry(content, placeholder_text="Teléfono", width=360)
        self.tel_entry.grid(row=7, column=0, sticky="ew", pady=(0,8))

        # Contraseña
        pass_label = CTkLabel(content, text="Contraseña:", anchor="w")
        pass_label.grid(row=8, column=0, sticky="w", pady=(4,2))
        self.regpass_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=360)
        self.regpass_entry.grid(row=9, column=0, sticky="ew", pady=(0,12))

        # Botón confirmar (vuelve a la pantalla principal y guarda usuario)
        confirm_btn = CTkButton(content, text="Confirmar datos", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._confirmar_registro)
        confirm_btn.grid(row=10, column=0, pady=(4,8), sticky="e")

        # manejar cierre de la ventana para devolver la pantalla principal
        self.protocol("WM_DELETE_WINDOW", self._volver_a_login)

    def _volver_a_login(self):
        # devolver la ventana que abrió este registro y cerrar esta
        if self.master is not None:
            try:
                self.master.deiconify()
            except Exception:
                pass
        self.destroy()

    def _confirmar_registro(self):
        # validar y guardar datos en archivo y en el perfil del master
        nombre = self.nombre_entry.get().strip()
        correo = self.correo_entry.get().strip()
        doc = self.doc_entry.get().strip()
        telefono = self.tel_entry.get().strip()
        pwd = self.regpass_entry.get().strip()

        if not (nombre and doc and pwd):
            messagebox.showerror("Datos incompletos", "Nombre, documento y contraseña son obligatorios.")
            return

        users = load_users()
        if doc in users:
            messagebox.showerror("Duplicado", f"Ya existe un usuario con documento {doc}.")
            return

        # guardar en archivo
        try:
            save_user({'name': nombre, 'password': pwd, 'doc': doc, 'email': correo, 'phone': telefono})
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el usuario: {e}")
            return

        # actualizar perfil del master (si existe)
        if self.master is not None:
            try:
                if not hasattr(self.master, 'user_profile'):
                    self.master.user_profile = {}
                self.master.user_profile.update({
                    'name': nombre,
                    'email': correo,
                    'doc': doc,
                    'millas': self.master.user_profile.get('millas', 0)
                })
            except Exception:
                pass

            try:
                self.master.deiconify()
            except Exception:
                pass

        messagebox.showinfo("Registro", "Usuario registrado y guardado.")
        self.destroy()

class LoginVuelos(CTk):
    # messagebox datos incorrectos
    def datos_incorrectos(self):
        messagebox.showerror("Error", "Documento o contraseña incorrectos.")

    # función para que la pantalla aparezca en el centro
    def CenterWindowToDisplay(Screen: CTk, width: int, height: int, scale_factor: float = 1.0):
        screen_width = Screen.winfo_screenwidth()
        screen_height = Screen.winfo_screenheight()
        x = int(((screen_width/2) - (width/2)) * scale_factor)
        y = int(((screen_height/2) - (height/1.5)) * scale_factor)
        return f"{width}x{height}+{x}+{y}"

    def clear_login_form(self):
        try:
            self.id_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        except Exception:
            pass

    def on_register(self):
        self.withdraw()
        if self.ventanaRegistro is None or not self.ventanaRegistro.winfo_exists():
            # pasar self como master para que la ventana de registro pueda volver a quien la abrió
            self.ventanaRegistro = ventanaRegistro(self)
        else:
            self.ventanaRegistro.focus()

    def on_login(self):
        doc = self.id_entry.get().strip()
        pwd = self.password_entry.get().strip()
        users = load_users()
        if doc and doc in users and users[doc]['password'] == pwd:
            # llenar perfil
            self.user_profile = {
                'name': users[doc]['name'],
                'doc': doc,
                'email': users[doc]['email'],
                'millas': getattr(self, 'user_profile', {}).get('millas', 0)
            }
            self.withdraw()
            # decisión admin si nombre inicia por "Admin" (simple)
            if users[doc]['name'].lower().startswith("admin"):
                hub = hubAdmin(self)
                hub.focus()
            else:
                hub = hubUsuario(self)
                hub.focus()
        else:
            self.datos_incorrectos()
    
    def __init__(self):
        super().__init__()
        self.geometry(self.CenterWindowToDisplay(500, 350, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('PLACEHOLDER')
        self.ventanaRegistro = None
        # perfil del usuario (se rellenará desde registro o login)
        self.user_profile = {'name': '', 'doc': '', 'email': '', 'millas': 0}

        # barra de arriba
        top_bar = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar.grid(row=0, column=0, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)

        #logo, titulo y slogan
        self.logo = customtkinter.CTkImage(light_image=Image.open('logo.png'), size=(50,50))
        logo_label = CTkLabel(top_bar, image=self.logo, text="")
        logo_label.grid(row=0, column=0, padx=(8,6), pady=6, sticky="w")

        title_label = CTkLabel(top_bar, text="VUELOS AEROPOLLITO", font=('Verdana', 12, 'bold'), anchor="w")
        title_label.grid(row=0, column=1, sticky="w", padx=(4,0), pady=6)

        slogan = CTkLabel(top_bar, text="Volando contigo!", font=('Serif', 8, 'italic'), anchor="e")
        slogan.grid(row=0, column=2, sticky="e", padx=(0,8), pady=6)
        top_bar.grid_columnconfigure(2, weight=0)

        # contenido principal
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew", padx=20, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Layout inside content
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=1)
        content.grid_columnconfigure(2, weight=1)

        # Texto de bienvenida
        welcome = CTkLabel(content, text="Bienvenido al Sistema [NOMBRE]!", font=('TkHeadingFont', 14))
        welcome.grid(row=0, column=0, columnspan=3, pady=(6, 14))


        # Usuario
        id_label = CTkLabel(content, text="Documento:", anchor="w")
        id_label.grid(row=1, column=1, sticky="w", padx=5, pady=(0,4))

        self.id_entry = CTkEntry(content, placeholder_text="Documento de identificación", width=300)
        self.id_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=4)

        # Contraseña
        password_label = CTkLabel(content, text="Contraseña:", anchor="w")
        password_label.grid(row=3, column=1, sticky="w", padx=5, pady=(8,4))

        self.password_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=300)
        self.password_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=4)

        # Botones
        register_btn = CTkButton(content, text="Registrarme", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_register)
        register_btn.grid(row=5, column=0, sticky="w", pady=(18,0), padx=8)
        self.bind('<Return>', lambda event: self.on_login())

        login_btn = CTkButton(content, text="Confirmar", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_login)
        login_btn.grid(row=5, column=2, sticky="e", pady=(18,0), padx=8)


        self.mainloop()

class ventanaRegistro(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 415, 470, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Registro')
        
        top_bar_login = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar_login.grid(row=0, column=0, sticky="ew")
        top_bar_login.grid_columnconfigure(1, weight=1)
        # Botón volver
        volver_btn = CTkButton(top_bar_login, text="Volver", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._volver_a_login)
        volver_btn.grid(row=0, column=0, sticky="w", padx=8, pady=10)
        registrolbl = CTkLabel(top_bar_login, text="Registrar usuario", font=('TkHeadingFont', 16), anchor="e")
        registrolbl.grid(row=0, column=2, padx=10, pady=10, sticky="e")
        top_bar_login.grid_columnconfigure(2, weight=0)

        # Frame de contenido
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, padx=20, pady=(8,12), sticky="nsew")
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Nombre
        nombre_label = CTkLabel(content, text="Nombre:", anchor="w")
        nombre_label.grid(row=0, column=0, sticky="w", pady=(4,2))
        self.nombre_entry = CTkEntry(content, placeholder_text="Nombre completo", width=360)
        self.nombre_entry.grid(row=1, column=0, sticky="ew", pady=(0,8))

        # Correo electrónico
        correo_label = CTkLabel(content, text="Correo electrónico:", anchor="w")
        correo_label.grid(row=2, column=0, sticky="w", pady=(4,2))
        self.correo_entry = CTkEntry(content, placeholder_text="correo@ejemplo.com", width=360)
        self.correo_entry.grid(row=3, column=0, sticky="ew", pady=(0,8))

        # Número de documento
        doc_label = CTkLabel(content, text="Número de documento:", anchor="w")
        doc_label.grid(row=4, column=0, sticky="w", pady=(4,2))
        self.doc_entry = CTkEntry(content, placeholder_text="Número de documento", width=360)
        self.doc_entry.grid(row=5, column=0, sticky="ew", pady=(0,8))

        # Teléfono (opcional)
        tel_label = CTkLabel(content, text="Teléfono:", anchor="w")
        tel_label.grid(row=6, column=0, sticky="w", pady=(4,2))
        self.tel_entry = CTkEntry(content, placeholder_text="Teléfono", width=360)
        self.tel_entry.grid(row=7, column=0, sticky="ew", pady=(0,8))

        # Contraseña
        pass_label = CTkLabel(content, text="Contraseña:", anchor="w")
        pass_label.grid(row=8, column=0, sticky="w", pady=(4,2))
        self.regpass_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=360)
        self.regpass_entry.grid(row=9, column=0, sticky="ew", pady=(0,12))

        # Botón confirmar (vuelve a la pantalla principal y guarda usuario)
        confirm_btn = CTkButton(content, text="Confirmar datos", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._confirmar_registro)
        confirm_btn.grid(row=10, column=0, pady=(4,8), sticky="e")

        # manejar cierre de la ventana para devolver la pantalla principal
        self.protocol("WM_DELETE_WINDOW", self._volver_a_login)

    def _volver_a_login(self):
        # devolver la ventana que abrió este registro y cerrar esta
        if self.master is not None:
            try:
                self.master.deiconify()
            except Exception:
                pass
        self.destroy()

    def _confirmar_registro(self):
        # validar y guardar datos en archivo y en el perfil del master
        nombre = self.nombre_entry.get().strip()
        correo = self.correo_entry.get().strip()
        doc = self.doc_entry.get().strip()
        telefono = self.tel_entry.get().strip()
        pwd = self.regpass_entry.get().strip()

        if not (nombre and doc and pwd):
            messagebox.showerror("Datos incompletos", "Nombre, documento y contraseña son obligatorios.")
            return

        users = load_users()
        if doc in users:
            messagebox.showerror("Duplicado", f"Ya existe un usuario con documento {doc}.")
            return

        # guardar en archivo
        try:
            save_user({'name': nombre, 'password': pwd, 'doc': doc, 'email': correo, 'phone': telefono})
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar el usuario: {e}")
            return

        # actualizar perfil del master (si existe)
        if self.master is not None:
            try:
                if not hasattr(self.master, 'user_profile'):
                    self.master.user_profile = {}
                self.master.user_profile.update({
                    'name': nombre,
                    'email': correo,
                    'doc': doc,
                    'millas': self.master.user_profile.get('millas', 0)
                })
            except Exception:
                pass

            try:
                self.master.deiconify()
            except Exception:
                pass

        messagebox.showinfo("Registro", "Usuario registrado y guardado.")
        self.destroy()

class hubAdmin(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 700, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")

        # obtener datos de perfil
        name = ""
        try:
            name = master.user_profile.get('name') if (master and hasattr(master, 'user_profile')) else ""
        except Exception:
            name = ""
        if not name:
            name = master.id_entry.get() if master else ""
        self.title(f'Hub Admin - {name}')

        # top bar (visible, similar a LoginVuelos)
        top_bar = CTkFrame(self, fg_color="#232634", height=48, corner_radius=0)
        top_bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)
        welcome_label = CTkLabel(top_bar, text=f"Bienvenido, Admin {name}!", font=('Verdana', 12, 'bold'))
        welcome_label.grid(row=0, column=0, padx=12, pady=8, sticky="w")

        # contenido principal: dos columnas (botones a la izquierda, perfil a la derecha)
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=16, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        # Columna izquierda: botones verticales
        left_frame = CTkFrame(content, fg_color="transparent")
        left_frame.grid(row=0, column=0, sticky="nsw", padx=(0,12), pady=4)
        left_frame.grid_rowconfigure(10, weight=1)
        cfg_vuelos_btn = CTkButton(left_frame, text="Configurar vuelos", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_config_vuelos)
        cfg_vuelos_btn.grid(row=0, column=0, pady=(4,8), sticky="ew")
        cfg_users_btn = CTkButton(left_frame, text="Configurar usuarios", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_config_usuarios)
        cfg_users_btn.grid(row=1, column=0, pady=(0,8), sticky="ew")
        # espacio y último botón cerrar sesión
        signout_btn = CTkButton(left_frame, text="Cerrar sesión", fg_color="#E04B4B", hover_color='#BF3B3B', command=self._sign_out)
        signout_btn.grid(row=9, column=0, pady=(12,0), sticky="swe")

        # Columna derecha: perfil del admin
        perfil_frame = CTkFrame(content, fg_color="#2B2F42", width=320, corner_radius=6)
        perfil_frame.grid(row=0, column=1, sticky="nsew", padx=(12,0))
        perfil_frame.grid_columnconfigure(0, weight=1)
        CTkLabel(perfil_frame, text="Tus datos", font=('Verdana', 12, 'bold')).grid(row=0, column=0, sticky="w", padx=8, pady=(8,6))
        name_lbl = CTkLabel(perfil_frame, text=f"Nombre: {name}", anchor="w")
        name_lbl.grid(row=1, column=0, sticky="w", padx=8, pady=2)
        doc_lbl = CTkLabel(perfil_frame, text=f"Documento: {master.user_profile.get('doc','') if (master and hasattr(master, 'user_profile')) else master.id_entry.get() if master else ''}", anchor="w")
        doc_lbl.grid(row=2, column=0, sticky="w", padx=8, pady=2)
        email_lbl = CTkLabel(perfil_frame, text=f"Correo: {master.user_profile.get('email','') if (master and hasattr(master, 'user_profile')) else ''}", anchor="w")
        email_lbl.grid(row=3, column=0, sticky="w", padx=8, pady=2)

    def _open_config_vuelos(self):
        # pasar el hub como parent (posicional) y el LoginVuelos como login_master (keyword)
        configVuelos(self, login_master=self.master)

    def _open_config_usuarios(self):
        # igual que arriba: hub como parent, login master separado
        configUsuarios(self, login_master=self.master)

    def _sign_out(self):
        # devolver al login y borrar formulario
        if self.master is not None:
            try:
                self.master.deiconify()
                if hasattr(self.master, 'clear_login_form'):
                    self.master.clear_login_form()
            except Exception:
                pass
        self.destroy()

class hubUsuario(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 700, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")

        name = ""
        mail = ""
        doc = ""
        millas = 0
        try:
            if master and hasattr(master, 'user_profile'):
                name = master.user_profile.get('name','')
                mail = master.user_profile.get('email','')
                doc = master.user_profile.get('doc','')
                millas = master.user_profile.get('millas',0)
        except Exception:
            pass
        if not name:
            name = master.id_entry.get() if master else ""
        self.title(f'Hub Usuario - {name}')

        # top bar
        top_bar = CTkFrame(self, fg_color="#232634", height=48, corner_radius=0)
        top_bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)
        welcome_label = CTkLabel(top_bar, text=f"Bienvenido, {name}!", font=('Verdana', 12, 'bold'))
        welcome_label.grid(row=0, column=0, padx=12, pady=8, sticky="w")

        # contenido principal: botones izquierda, perfil derecha
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=16, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        left_frame = CTkFrame(content, fg_color="transparent")
        left_frame.grid(row=0, column=0, sticky="nsw", padx=(0,12))
        buscar_btn = CTkButton(left_frame, text="Buscar vuelo", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_buscar_vuelo)
        buscar_btn.grid(row=0, column=0, pady=(4,8), sticky="ew")
        ver_reservas_btn = CTkButton(left_frame, text="Ver mis reservas", fg_color="#3454d1", hover_color='#34d1bf', command=self._ver_reservas)
        ver_reservas_btn.grid(row=1, column=0, pady=(0,8), sticky="ew")
        cancelar_btn = CTkButton(left_frame, text="Cancelar reserva", fg_color="#3454D1", hover_color='#34d1bf', command=self._cancelar_reserva)
        cancelar_btn.grid(row=2, column=0, pady=(0,8), sticky="ew")
        # botón para logout también disponible
        logout_btn = CTkButton(left_frame, text="Cerrar sesión", fg_color="#E04B4B", hover_color='#BF3B3B', command=self._sign_out)
        logout_btn.grid(row=9, column=0, pady=(12,0), sticky="swe")

        perfil_frame = CTkFrame(content, fg_color="#2B2F42", corner_radius=6)
        perfil_frame.grid(row=0, column=1, sticky="nsew", padx=(12,0))
        CTkLabel(perfil_frame, text="Tus datos", font=('Verdana', 12, 'bold')).grid(row=0, column=0, sticky="w", padx=8, pady=(8,6))
        CTkLabel(perfil_frame, text=f"Nombre: {name}").grid(row=1, column=0, sticky="w", padx=8)
        CTkLabel(perfil_frame, text=f"Documento: {doc}").grid(row=2, column=0, sticky="w", padx=8)
        CTkLabel(perfil_frame, text=f"Correo: {mail}").grid(row=3, column=0, sticky="w", padx=8)
        self.millas_label = CTkLabel(perfil_frame, text=f"Millas disponibles: {millas}")
        self.millas_label.grid(row=4, column=0, sticky="w", padx=8, pady=(6,8))

    def _open_buscar_vuelo(self):
        # pasar login master para que la búsqueda/reserva pueda actualizar millas
        BuscarVuelo(self, login_master=self.master)

    def _ver_reservas(self):
        VerReservas(self, login_master=self.master)

    def _cancelar_reserva(self):
        messagebox.showinfo("Cancelar", "Función 'Cancelar reserva' no implementada aún.")

    def actualizar_millas(self):
        try:
            millas = self.master.user_profile.get('millas',0)
            self.millas_label.configure(text=f"Millas disponibles: {millas}")
        except Exception:
            pass

    def _sign_out(self):
        if self.master is not None:
            try:
                self.master.deiconify()
                if hasattr(self.master, 'clear_login_form'):
                    self.master.clear_login_form()
            except Exception:
                pass
        self.destroy()
    def _ver_reservas(self):
        VerReservas(self, login_master=self.master)

    def _cancelar_reserva(self):
        # abrir la misma ventana de VerReservas para mostrar y cancelar
        VerReservas(self, login_master=self.master)

class BuscarVuelo(CTkToplevel):
    def __init__(self, master=None, login_master=None, **kwargs):
        # master: hub window; login_master: instancia LoginVuelos para actualizar perfil/millas
        super().__init__(master)
        self.login_master = login_master if login_master is not None else kwargs.get('login_master', None)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 400, 420, self._get_window_scaling()))
        self.flights = load_flights()
        self.title("Buscar Vuelo")
        # construir lista de ciudades desde vuelos
        cities = set()
        for f in self.flights:
            cities.add(f['origen'])
            cities.add(f['destino'])
        self.cities = ["(Todos)"] + sorted(list(cities))

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        # filtros usando CTkOptionMenu y botón con imagen
        filtro_frame = CTkFrame(content, fg_color="transparent")
        filtro_frame.pack(fill='x', pady=(0,8))
        CTkLabel(filtro_frame, text="Origen:").grid(row=0,column=0, padx=4, pady=4, sticky="w")
        self.origen_cb = customtkinter.CTkOptionMenu(filtro_frame, values=self.cities)
        self.origen_cb.grid(row=0,column=1, padx=4, pady=4)
        CTkLabel(filtro_frame, text="Destino:").grid(row=0,column=2, padx=4, pady=4, sticky="w")
        self.destino_cb = customtkinter.CTkOptionMenu(filtro_frame, values=self.cities)
        self.destino_cb.grid(row=0,column=3, padx=4, pady=4)

        # imagen lupa (usa lupa.png en la misma carpeta)
        try:
            self.lupa_img = customtkinter.CTkImage(light_image=Image.open('lupa.png'), size=(20,20))
            buscar_btn = CTkButton(filtro_frame, image=self.lupa_img, text="", width=36, height=36, command=self._buscar)
        except Exception:
            buscar_btn = CTkButton(filtro_frame, text="Buscar", command=self._buscar)
        buscar_btn.grid(row=0, column=4, padx=8)

        # resultados: Listbox con fondo oscuro
        resultado_frame = CTkFrame(content, fg_color="transparent")
        resultado_frame.pack(fill='both', expand=True)
        self.listbox = tk.Listbox(resultado_frame, height=8, bg="#1f2330", fg="#EFEFEF", selectbackground="#3454d1", highlightthickness=0)
        self.listbox.pack(side='left', fill='both', expand=True, padx=(0,8))
        self.scrollbar = tk.Scrollbar(resultado_frame, orient='vertical', command=self.listbox.yview)
        self.scrollbar.pack(side='right', fill='y')
        self.listbox.config(yscrollcommand=self.scrollbar.set)

        action_frame = CTkFrame(content, fg_color="transparent")
        action_frame.pack(fill='x', pady=(8,0))
        reservar_btn = CTkButton(action_frame, text="Reservar", command=self._reservar_seleccion)
        reservar_btn.pack(side='right')

        # inicializar lista completa
        self._llenar_lista(self.flights)

    def _llenar_lista(self, flights):
        self.listbox.delete(0, tk.END)
        for f in flights:
            self.listbox.insert(tk.END, f"{f['code']} | {f['origen']} -> {f['destino']} | {f['dia']} {f['hora']} | pref:{f['sillas_pref']} eco:{f['sillas_eco']}")

    def _buscar(self):
        origen = self.origen_cb.get().strip() if hasattr(self.origen_cb, 'get') else ''
        destino = self.destino_cb.get().strip() if hasattr(self.destino_cb, 'get') else ''
        if origen in ("", "(Todos)"):
            origen = ""
        if destino in ("", "(Todos)"):
            destino = ""
        results = []
        for f in self.flights:
            ok = True
            if origen and origen != f['origen']:
                ok = False
            if destino and destino != f['destino']:
                ok = False
            if ok:
                results.append(f)
        if not origen and not destino:
            results = self.flights
        self._llenar_lista(results)

    def _reservar_seleccion(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Seleccionar", "Seleccione primero un vuelo.")
            return
        idx = sel[0]
        line = self.listbox.get(idx)
        flight_code = line.split('|')[0].strip()
        flight = next((f for f in self.flights if f['code']==flight_code), None)
        if flight:
            ReservarVuelo(self, flight=flight, login_master=self.login_master)

class ReservarVuelo(CTkToplevel):
    def __init__(self, master=None, flight=None, login_master=None, **kwargs):
        super().__init__(master)
        self.login_master = login_master if login_master is not None else kwargs.get('login_master', None)
        self.flight = flight
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 520, 500, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title("Reservar Vuelo")

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        # Mostrar info del vuelo (usar claves definidas en load_flights)
        CTkLabel(content, text=f"Vuelo: {flight['code']} - {flight['origen']} -> {flight['destino']}").pack(anchor='w', pady=(0,6))
        CTkLabel(content, text=f"Día/Hora: {flight.get('dia','')} {flight.get('hora','')}").pack(anchor='w')
        CTkLabel(content, text=f"Sillas disponibles - Preferencial: {flight.get('sillas_pref',0)}  Económica: {flight.get('sillas_eco',0)}").pack(anchor='w', pady=(0,6))
        CTkLabel(content, text=f"Precio preferencial: ${flight.get('price_pref', PRICE_PREF)}  Precio económica: ${flight.get('price_eco', PRICE_ECO)}").pack(anchor='w', pady=(0,6))

        # seleccionar tipo de silla (radio) y cantidad (CTkOptionMenu máximo 3)
        tipo_frame = CTkFrame(content, fg_color="transparent")
        tipo_frame.pack(fill='x', pady=(6,4))
        CTkLabel(tipo_frame, text="Tipo de silla:").grid(row=0, column=0, sticky='w', padx=4)
        self.tipo_var = tk.StringVar(value="eco")
        # radiobuttons
        CTkRadioButton(tipo_frame, text="Económica", variable=self.tipo_var, value="eco").grid(row=0, column=1, padx=6)
        CTkRadioButton(tipo_frame, text="Preferencial", variable=self.tipo_var, value="pref").grid(row=0, column=2, padx=6)

        CTkLabel(content, text="Cantidad de sillas (máx 3):").pack(anchor='w', pady=(6,0))
        self.cantidad_opt = customtkinter.CTkOptionMenu(content, values=["1","2","3"])
        self.cantidad_opt.set("1")
        self.cantidad_opt.pack(anchor='w', pady=(0,6))

        # horas (usar CTkOptionMenu, la fuente 'hora' en vuelos es string)
        CTkLabel(content, text="Hora:").pack(anchor='w')
        horas = [flight['hora']] if isinstance(flight.get('hora', None), str) else flight.get('hora', [])
        if not horas:
            horas = ["--"]
        self.hora_opt = customtkinter.CTkOptionMenu(content, values=horas)
        self.hora_opt.set(horas[0])
        self.hora_opt.pack(anchor='w', pady=(0,6))

        # maletas (conteos)
        CTkLabel(content, text="Maletas de cabina:").pack(anchor='w')
        self.cabina_spin = tk.Spinbox(content, from_=0, to=5, width=5)
        self.cabina_spin.pack(anchor='w', pady=(0,6))
        CTkLabel(content, text="Maletas de bodega:").pack(anchor='w')
        self.bodega_spin = tk.Spinbox(content, from_=0, to=5, width=5)
        self.bodega_spin.pack(anchor='w', pady=(0,6))

        # botón calcular y confirmar
        btn_frame = CTkFrame(content, fg_color="transparent")
        btn_frame.pack(fill='x', pady=(8,0))
        CTkButton(btn_frame, text="Calcular precio", command=self._calcular_precio).pack(side='left')
        CTkButton(btn_frame, text="Confirmar reserva", fg_color="#3454d1", hover_color='#34d1bf', command=self._confirmar).pack(side='right')

        self.price_label = CTkLabel(content, text="Total estimado: $0")
        self.price_label.pack(anchor='w', pady=(8,0))

    def _calcular_precio(self):
        tipo = self.tipo_var.get()
        cantidad = int(self.cantidad_opt.get()) if self.cantidad_opt.get() else 1
        cabina = int(self.cabina_spin.get())
        bodega = int(self.bodega_spin.get())
        total = 0
        if tipo == "pref":
            total += self.flight.get('price_pref', PRICE_PREF) * cantidad
            # preferencial incluye 1 maleta de bodega por silla (asumido)
            free_bodega = cantidad
            extra_bodega = max(0, bodega - free_bodega)
            total += extra_bodega * HOLD_EXTRA_PREF
            # maletas de cabina incluidas para preferencial
        else:
            total += self.flight.get('price_eco', PRICE_ECO) * cantidad
            # cabina para eco cuesta CABIN_EXTRA_ECO cada
            total += cabina * CABIN_EXTRA_ECO
            total += bodega * HOLD_EXTRA_ECO
        self.price_label.configure(text=f"Total estimado: ${int(total)}")
        return total

    def _confirmar(self):
        try:
            cantidad = int(self.cantidad_opt.get())
        except Exception:
            messagebox.showwarning("Datos", "Seleccione cantidad válida.")
            return
        tipo = self.tipo_var.get()
        cabina = int(self.cabina_spin.get())
        bodega = int(self.bodega_spin.get())
        total = self._calcular_precio()
        if messagebox.askyesno("Confirmar", f"Total ${int(total)} por {cantidad} silla(s). Confirmar reserva?"):
            # comprobar disponibilidad y restar
            flights_all = load_flights()
            fl = next((f for f in flights_all if f['code'] == self.flight['code']), None)
            if not fl:
                messagebox.showerror("Error", "Vuelo no encontrado al confirmar.")
                return
            if tipo == "pref":
                if fl['sillas_pref'] < cantidad:
                    messagebox.showerror("Sillas", "No hay suficientes sillas preferenciales disponibles.")
                    return
                fl['sillas_pref'] -= cantidad
            else:
                if fl['sillas_eco'] < cantidad:
                    messagebox.showerror("Sillas", "No hay suficientes sillas económicas disponibles.")
                    return
                fl['sillas_eco'] -= cantidad
            # guardar vuelos
            save_flights(flights_all)

            # crear y guardar reserva
            res_list = load_reservations()
            res_id = generate_reservation_id()
            user_doc = ''
            if self.login_master and hasattr(self.login_master, 'user_profile'):
                user_doc = self.login_master.user_profile.get('doc','')
            reservation = {
                'id': res_id,
                'user_doc': user_doc,
                'flight_code': self.flight['code'],
                'pref': cantidad if tipo == 'pref' else 0,
                'eco': cantidad if tipo == 'eco' else 0,
                'maletas_cabina': cabina,
                'maletas_bodega': bodega,
                'total': float(total)
            }
            res_list.append(reservation)
            save_reservations(res_list)

            # sumar millas
            if self.login_master is not None:
                if not hasattr(self.login_master, 'user_profile'):
                    self.login_master.user_profile = {'millas': 0}
                self.login_master.user_profile['millas'] = self.login_master.user_profile.get('millas', 0) + MILLAS_POR_RESERVA
                # intentar actualizar hubUsuario si está abierto
                try:
                    for w in self.login_master.winfo_children():
                        if isinstance(w, hubUsuario):
                            w.actualizar_millas()
                except Exception:
                    pass

            messagebox.showinfo("Reservado", f"Reserva confirmada. Número: {res_id}")
            self.destroy()

class CrearVuelo(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 520, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Crear Vuelo')

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        CTkLabel(content, text="Código:").grid(row=0, column=0, sticky='w', padx=4, pady=4)
        self.code_e = CTkEntry(content, width=250)
        self.code_e.grid(row=0, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Origen:").grid(row=1, column=0, sticky='w', padx=4, pady=4)
        self.orig_e = CTkEntry(content, width=250)
        self.orig_e.grid(row=1, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Destino:").grid(row=2, column=0, sticky='w', padx=4, pady=4)
        self.dest_e = CTkEntry(content, width=250)
        self.dest_e.grid(row=2, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Día:").grid(row=3, column=0, sticky='w', padx=4, pady=4)
        self.dia_e = CTkEntry(content, width=250)
        self.dia_e.grid(row=3, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Hora (HH:MM):").grid(row=4, column=0, sticky='w', padx=4, pady=4)
        self.hora_e = CTkEntry(content, width=250)
        self.hora_e.grid(row=4, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Sillas preferenciales:").grid(row=5, column=0, sticky='w', padx=4, pady=4)
        self.pref_e = CTkEntry(content, width=100)
        self.pref_e.grid(row=5, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Sillas económicas:").grid(row=6, column=0, sticky='w', padx=4, pady=4)
        self.eco_e = CTkEntry(content, width=100)
        self.eco_e.grid(row=6, column=1, pady=4, sticky='w')

        btn_frame = CTkFrame(content, fg_color="transparent")
        btn_frame.grid(row=7, column=0, columnspan=2, sticky='ew', pady=(12,0))
        CTkButton(btn_frame, text="Crear vuelo", fg_color="#3454d1", hover_color='#34d1bf', command=self._create).pack(side='right')

    def _create(self):
        code = self.code_e.get().strip()
        origen = self.orig_e.get().strip().capitalize()
        destino = self.dest_e.get().strip().capitalize()
        dia = self.dia_e.get().strip().upper()
        hora = self.hora_e.get().strip()
        try:
            pref = int(self.pref_e.get())
            eco = int(self.eco_e.get())
        except Exception:
            messagebox.showerror("Datos", "Sillas deben ser numéricas.")
            return
        if not (code and origen and destino and dia and hora):
            messagebox.showerror("Datos", "Complete todos los campos.")
            return
        flights = load_flights()
        if any(f['code'] == code for f in flights):
            messagebox.showerror("Código", "Ya existe un vuelo con ese código.")
            return
        flights.append({
            'code': code,
            'origen': origen,
            'destino': destino,
            'dia': dia,
            'hora': hora,
            'sillas_pref': pref,
            'sillas_eco': eco,
            'price_pref': PRICE_PREF,
            'price_eco': PRICE_ECO
        })
        save_flights(flights)
        messagebox.showinfo("Creado", f"Vuelo {code} creado.")
        self.destroy()

class VerVuelo(CTkToplevel):
     def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 700, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Ver Vuelos con Sillas')
        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        # lista de vuelos con sillas disponibles
        self.listbox = tk.Listbox(content, height=20, bg="#1f2330", fg="#EFEFEF", selectbackground="#3454d1", highlightthickness=0)
        self.listbox.pack(side='left', fill='both', expand=True, padx=(0,8))
        self.sb = tk.Scrollbar(content, command=self.listbox.yview)
        self.sb.pack(side='right', fill='y')
        self.listbox.config(yscrollcommand=self.sb.set)

        btn_frame = CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill='x', pady=(8,0))
        CTkButton(btn_frame, text="Ver detalles", command=self._ver_detalle).pack(side='left', padx=6)
        CTkButton(btn_frame, text="Refrescar", command=self._load).pack(side='right', padx=6)

        self._load()

     def _load(self):
        self.listbox.delete(0, tk.END)
        flights = load_flights()
        res = load_reservations()
        for f in flights:
            sold_pref = sum(r['pref'] for r in res if r['flight_code'] == f['code'])
            sold_eco = sum(r['eco'] for r in res if r['flight_code'] == f['code'])
            if f.get('sillas_pref', 0) > 0 or f.get('sillas_eco', 0) > 0:
                self.listbox.insert(tk.END, f"{f['code']} | {f['origen']}->{f['destino']} | {f['dia']} {f['hora']} | pref_avail:{f['sillas_pref']} eco_avail:{f['sillas_eco']} | sold pref:{sold_pref} eco:{sold_eco}")

     def _ver_detalle(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Seleccionar", "Seleccione un vuelo.")
            return
        line = self.listbox.get(sel[0])
        code = line.split('|')[0].strip()
        flights = load_flights()
        f = next((x for x in flights if x['code'] == code), None)
        if not f:
            messagebox.showinfo("Detalle", "Vuelo no encontrado.")
            return
        res = load_reservations()
        sold_pref = sum(r['pref'] for r in res if r['flight_code'] == code)
        sold_eco = sum(r['eco'] for r in res if r['flight_code'] == code)
        messagebox.showinfo("Detalle vuelo", f"Código: {f['code']}\n{f['origen']} -> {f['destino']}\n{f['dia']} {f['hora']}\nSillas pref disponibles: {f['sillas_pref']} (vendidas: {sold_pref})\nSillas eco disponibles: {f['sillas_eco']} (vendidas: {sold_eco})")

class BuscarUsuario(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 400, 200, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Buscar Usuario')
        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        CTkLabel(content, text="Documento:").grid(row=0, column=0, sticky='w')
        self.doc_entry = CTkEntry(content, placeholder_text="Documento")
        self.doc_entry.grid(row=1, column=0, sticky='ew', pady=(4,8))
        buscar_btn = CTkButton(content, text="Buscar", command=self._buscar)
        buscar_btn.grid(row=2, column=0, sticky='e')

    def _buscar(self):
        doc = self.doc_entry.get().strip()
        if not doc:
            messagebox.showwarning("Documento", "Ingrese un documento para buscar.")
            return
        users = load_users()
        if doc in users:
            u = users[doc]
            messagebox.showinfo("Usuario encontrado", f"Nombre: {u['name']}\nDocumento: {doc}\nCorreo: {u['email']}\nTel: {u['phone']}")
        else:
            messagebox.showinfo("No encontrado", f"No se encontró usuario con documento {doc}.")

class BuscarVueloAdmin(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 420, 220, self._get_window_scaling()))
        self.resizable(False, False)
        self.title("Buscar vuelo (Admin)")
        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        CTkLabel(content, text="Código de vuelo:").grid(row=0, column=0, sticky='w')
        self.code_e = CTkEntry(content)
        self.code_e.grid(row=0, column=1, pady=4)
        CTkButton(content, text="Buscar", command=self._buscar).grid(row=1, column=1, sticky='e', pady=(8,0))

    def _buscar(self):
        code = self.code_e.get().strip()
        if not code:
            messagebox.showwarning("Código", "Ingrese un código de vuelo.")
            return
        flights = load_flights()
        f = next((x for x in flights if x['code'] == code), None)
        if not f:
            messagebox.showinfo("Buscar", "No se encontró el vuelo.")
            return
        # contar sillas vendidas: leer reservas
        res = load_reservations()
        sold_pref = sum(r['pref'] for r in res if r['flight_code'] == code)
        sold_eco = sum(r['eco'] for r in res if r['flight_code'] == code)
        messagebox.showinfo("Vuelo", f"Código: {f['code']}\n{f['origen']} -> {f['destino']}\n{f['dia']} {f['hora']}\nSillas preferenciales disponibles: {f['sillas_pref']} ({sold_pref} vendidas)\nSillas económicas disponibles: {f['sillas_eco']} ({sold_eco} vendidas)")

class configVuelos(CTkToplevel):
    def __init__(self, master=None, **kwargs):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 500, 300, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Configurar Vuelos')

        login_master = kwargs.get('login_master', None)

        top = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top.pack(fill='x')
        CTkLabel(top, text="Configuración de Vuelos", font=('Verdana', 12, 'bold')).pack(side='left', padx=8, pady=6)
        back_btn = CTkButton(top, text="Volver", fg_color="#3454d1", command=self.destroy)
        back_btn.pack(side='right', padx=8, pady=6)

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        crear_btn = CTkButton(content, text="Crear vuelo", command=lambda: CrearVuelo(self))
        crear_btn.pack(fill='x', pady=6)
        # pasar login_master explícito para evitar duplicar 'master'
        buscar_btn = CTkButton(content, text="Buscar vuelo", command=lambda: BuscarVueloAdmin(self))
        buscar_btn.pack(fill='x', pady=6)
        ver_btn = CTkButton(content, text="Ver vuelos con sillas", command=lambda: VerVuelo(self))
        ver_btn.pack(fill='x', pady=6)

class configUsuarios(CTkToplevel):
    def __init__(self, master=None, **kwargs):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 400, 220, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Configurar Usuarios')

        login_master = kwargs.get('login_master', None)

        top = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top.pack(fill='x')
        CTkLabel(top, text="Configuración de Usuarios", font=('Verdana', 12, 'bold')).pack(side='left', padx=8, pady=6)
        back_btn = CTkButton(top, text="Volver", fg_color="#3454d1", command=self.destroy)
        back_btn.pack(side='right', padx=8, pady=6)

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        crear_btn = CTkButton(content, text="Crear/Registrar usuario", command=lambda: ventanaRegistro(self))
        crear_btn.pack(fill='x', pady=6)
        buscar_btn = CTkButton(content, text="Buscar usuario", command=lambda: BuscarUsuario(self))
        buscar_btn.pack(fill='x', pady=6)

class VerReservas(CTkToplevel):
    def __init__(self, master=None, login_master=None):
        super().__init__(master)
        self.login_master = login_master
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 600, 300, self._get_window_scaling()))
        self.resizable(False, False)
        self.title("Mis Reservas")
        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        self.listbox = tk.Listbox(content, height=5, bg="#1f2330", fg="#EFEFEF", selectbackground="#3454d1", highlightthickness=0)
        self.listbox.pack(side='left', fill='both', expand=True, padx=(0,8))
        self.sb = tk.Scrollbar(content, command=self.listbox.yview)
        self.sb.pack(side='right', fill='y')
        self.listbox.config(yscrollcommand=self.sb.set)

        btn_frame = CTkFrame(self, fg_color="transparent")
        btn_frame.pack(fill='x', pady=(8,0))
        CTkButton(btn_frame, text="Cancelar reserva", fg_color="#E04B4B", hover_color='#BF3B3B', command=self._cancel).pack(side='left', padx=6)
        CTkButton(btn_frame, text="Editar reserva", fg_color="#34A853", hover_color='#2E8E45', command=self._edit).pack(side='left', padx=6)
        CTkButton(btn_frame, text="Refrescar", command=self._load).pack(side='right', padx=6)

        self._load()

    def _load(self):
        self.listbox.delete(0, tk.END)
        all_res = load_reservations()
        user_doc = self.login_master.user_profile.get('doc') if (self.login_master and hasattr(self.login_master,'user_profile')) else ''
        self.user_res = [r for r in all_res if r['user_doc'] == user_doc]
        for r in self.user_res:
            self.listbox.insert(tk.END, f"{r['id']} | {r['flight_code']} | pref:{r['pref']} eco:{r['eco']} cabina:{r['maletas_cabina']} bodega:{r['maletas_bodega']} total:${int(r['total'])}")

    def _cancel(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Seleccionar", "Seleccione una reserva.")
            return
        idx = sel[0]
        r = self.user_res[idx]
        if not messagebox.askyesno("Confirmar", f"Cancelar reserva {r['id']}?"):
            return
        # restituir sillas al vuelo
        flights = load_flights()
        fl = next((f for f in flights if f['code'] == r['flight_code']), None)
        if fl:
            fl['sillas_pref'] = fl.get('sillas_pref', 0) + r.get('pref', 0)
            fl['sillas_eco'] = fl.get('sillas_eco', 0) + r.get('eco', 0)
            save_flights(flights)
        # quitar reserva
        all_res = load_reservations()
        all_res = [rr for rr in all_res if rr['id'] != r['id']]
        save_reservations(all_res)
        # restar millas del usuario
        if self.login_master is not None and hasattr(self.login_master, 'user_profile'):
            self.login_master.user_profile['millas'] = max(0, self.login_master.user_profile.get('millas',0) - MILLAS_POR_RESERVA)
            # actualizar hubUsuario si está abierto
            try:
                for w in self.login_master.winfo_children():
                    if isinstance(w, hubUsuario):
                        w.actualizar_millas()
            except Exception:
                pass
        messagebox.showinfo("Cancelado", f"Reserva {r['id']} cancelada.")
        self._load()

    def _edit(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Seleccionar", "Seleccione una reserva.")
            return
        idx = sel[0]
        r = self.user_res[idx]
        EditarReserva(self, reservation=r, login_master=self.login_master, refresh_cb=self._load)

class EditarReserva(CTkToplevel):
    def __init__(self, master=None, reservation=None, login_master=None, refresh_cb=None):
        super().__init__(master)
        self.reservation = reservation
        self.login_master = login_master
        self.refresh_cb = refresh_cb
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 520, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title(f"Editar Reserva {reservation.get('id','')}")

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        CTkLabel(content, text=f"Vuelo: {reservation.get('flight_code','')}").grid(row=0, column=0, sticky='w', pady=4)
        CTkLabel(content, text="Pref actuales:").grid(row=1, column=0, sticky='w')
        self.pref_var = customtkinter.CTkOptionMenu(content, values=[str(i) for i in range(0,4)])
        self.pref_var.set(str(reservation.get('pref',0)))
        self.pref_var.grid(row=1, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Eco actuales:").grid(row=2, column=0, sticky='w')
        self.eco_var = customtkinter.CTkOptionMenu(content, values=[str(i) for i in range(0,4)])
        self.eco_var.set(str(reservation.get('eco',0)))
        self.eco_var.grid(row=2, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Maletas cabina:").grid(row=3, column=0, sticky='w')
        self.cabina_spin = tk.Spinbox(content, from_=0, to=5, width=5)
        self.cabina_spin.delete(0, tk.END)
        self.cabina_spin.insert(0, str(reservation.get('maletas_cabina',0)))
        self.cabina_spin.grid(row=3, column=1, pady=4, sticky='w')

        CTkLabel(content, text="Maletas bodega:").grid(row=4, column=0, sticky='w')
        self.bodega_spin = tk.Spinbox(content, from_=0, to=5, width=5)
        self.bodega_spin.delete(0, tk.END)
        self.bodega_spin.insert(0, str(reservation.get('maletas_bodega',0)))
        self.bodega_spin.grid(row=4, column=1, pady=4, sticky='w')

        CTkButton(content, text="Calcular nuevo precio", command=self._calcular_precio).grid(row=5, column=1, sticky='e', pady=(8,0))
        self.price_label = CTkLabel(content, text=f"Precio actual: ${int(reservation.get('total',0))}")
        self.price_label.grid(row=6, column=0, columnspan=2, sticky='w', pady=(8,0))

        CTkButton(content, text="Guardar cambios", fg_color="#3454d1", hover_color='#34d1bf', command=self._save).grid(row=7, column=1, sticky='e', pady=(12,0))

    def _calcular_precio(self):
        pref = int(self.pref_var.get())
        eco = int(self.eco_var.get())
        cabina = int(self.cabina_spin.get())
        bodega = int(self.bodega_spin.get())
        total = 0
        # preferencial precio
        total += pref * PRICE_PREF
        # economica precio
        total += eco * PRICE_ECO
        # maletas: cabina included for pref, extra for eco
        total += max(0, cabina - 0) * CABIN_EXTRA_ECO  # simple rule
        # bodega: preferencial includes 1 per pref seat, extras cost HOLD_EXTRA_PREF; all eco cost HOLD_EXTRA_ECO
        free_bodega = pref
        extra_bodega = max(0, bodega - free_bodega)
        total += extra_bodega * HOLD_EXTRA_PREF
        total += eco * HOLD_EXTRA_ECO  # assume all eco bodega count charged (simple)
        self.price_label.configure(text=f"Nuevo total estimado: ${int(total)}")
        return total

    def _save(self):
        new_pref = int(self.pref_var.get())
        new_eco = int(self.eco_var.get())
        new_cabina = int(self.cabina_spin.get())
        new_bodega = int(self.bodega_spin.get())
        old_pref = self.reservation.get('pref',0)
        old_eco = self.reservation.get('eco',0)

        flights = load_flights()
        fl = next((f for f in flights if f['code'] == self.reservation['flight_code']), None)
        if not fl:
            messagebox.showerror("Error", "Vuelo no encontrado.")
            return

        # calcular deltas y comprobar disponibilidad (si se incrementa)
        delta_pref = new_pref - old_pref
        delta_eco = new_eco - old_eco
        if delta_pref > 0 and fl.get('sillas_pref',0) < delta_pref:
            messagebox.showerror("Disponibilidad", "No hay suficientes sillas preferenciales.")
            return
        if delta_eco > 0 and fl.get('sillas_eco',0) < delta_eco:
            messagebox.showerror("Disponibilidad", "No hay suficientes sillas económicas.")
            return

        # aplicar cambios en vuelo
        fl['sillas_pref'] = fl.get('sillas_pref',0) - delta_pref
        fl['sillas_eco'] = fl.get('sillas_eco',0) - delta_eco
        save_flights(flights)

        # actualizar reserva
        all_res = load_reservations()
        for rr in all_res:
            if rr['id'] == self.reservation['id']:
                rr['pref'] = new_pref
                rr['eco'] = new_eco
                rr['maletas_cabina'] = new_cabina
                rr['maletas_bodega'] = new_bodega
                rr['total'] = float(self._calcular_precio())
                break
        save_reservations(all_res)

        messagebox.showinfo("Guardado", "Reserva actualizada.")
        if callable(self.refresh_cb):
            try:
                self.refresh_cb()
            except Exception:
                pass
        self.destroy()

if __name__ == "__main__":
    LoginVuelos()