### TO-DO ####
# Implementar codigo de login / registro
# Cambiar image a CTkImage
#
#############
# Paleta de colores:
# Fondo #2B2F42
# Blanco #EFEFEF
# Azul #3454D1
# Turquesa #34D1BF
#############
import customtkinter
from customtkinter import CTk, CTkFrame, CTkLabel, CTkEntry, CTkButton, CTkImage, CTkToplevel
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk
from PIL import Image, ImageTk

customtkinter.set_appearance_mode('dark')

class LoginVuelos(CTk):
    # messagebox datos incorrectos
    def datos_incorrectos(self):
        messagebox.showerror("Error", "Documento o contraseña incorrectos.")


    # función para que la pantalla aparezca en el centro
    def CenterWindowToDisplay(Screen: CTk, width: int, height: int, scale_factor: float = 1.0):
        screen_width = Screen.winfo_screenwidth()
        screen_height = Screen.winfo_screenheight()
        x = int(((screen_width/2) - (width/2)) * scale_factor)
        y = int(((screen_height/2) - (height/1.5)) * scale_factor)
        return f"{width}x{height}+{x}+{y}"

    def clear_login_form(self):
        try:
            self.id_entry.delete(0, tk.END)
            self.password_entry.delete(0, tk.END)
        except Exception:
            pass

    def on_register(self):
        self.withdraw()
        if self.ventanaRegistro is None or not self.ventanaRegistro.winfo_exists():
            # pasar self como master para que la ventana de registro pueda volver a quien la abrió
            self.ventanaRegistro = ventanaRegistro(self)
        else:
            self.ventanaRegistro.focus()

    def on_login(self):
        # Esta función debería autenticar. Por ahora muestra la ventana correspondiente para pruebas.
        print("Log in clicked:", self.id_entry.get(), self.password_entry.get())
        # ejemplo: abrir hub admin si el documento empieza por 'A', si no abrir hubUsuario
        doc = self.id_entry.get().strip()
        if doc.upper().startswith("A"):
            # abrir hub admin
            self.withdraw()
            hub = hubAdmin(self)
            hub.focus()
        elif doc:
            self.withdraw()
            hub = hubUsuario(self)
            hub.focus()
        else:
            self.datos_incorrectos()
    
    def __init__(self):
        super().__init__()
        self.geometry(self.CenterWindowToDisplay(500, 350, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('PLACEHOLDER')
        self.ventanaRegistro = None
        # perfil del usuario (se rellenará desde registro o login)
        self.user_profile = {'name': '', 'doc': '', 'email': '', 'millas': 0}

        # barra de arriba
        top_bar = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar.grid(row=0, column=0, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)

        #logo, titulo y slogan
        self.logo = customtkinter.CTkImage(light_image=Image.open('logo.png'), size=(50,50))
        logo_label = CTkLabel(top_bar, image=self.logo, text="")
        logo_label.grid(row=0, column=0, padx=(8,6), pady=6, sticky="w")

        title_label = CTkLabel(top_bar, text="VUELOS [NOMBRE]", font=('Verdana', 12, 'bold'), anchor="w")
        title_label.grid(row=0, column=1, sticky="w", padx=(4,0), pady=6)

        slogan = CTkLabel(top_bar, text="Algún slogan bonito aquí!", font=('Serif', 8, 'italic'), anchor="e")
        slogan.grid(row=0, column=2, sticky="e", padx=(0,8), pady=6)
        top_bar.grid_columnconfigure(2, weight=0)

        # contenido principal
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, sticky="nsew", padx=20, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Layout inside content
        content.grid_columnconfigure(0, weight=1)
        content.grid_columnconfigure(1, weight=1)
        content.grid_columnconfigure(2, weight=1)

        # Texto de bienvenida
        welcome = CTkLabel(content, text="Bienvenido al Sistema [NOMBRE]!", font=('TkHeadingFont', 14))
        welcome.grid(row=0, column=0, columnspan=3, pady=(6, 14))


        # Usuario
        id_label = CTkLabel(content, text="Documento:", anchor="w")
        id_label.grid(row=1, column=1, sticky="w", padx=5, pady=(0,4))

        self.id_entry = CTkEntry(content, placeholder_text="Documento de identificación", width=300)
        self.id_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=4)

        # Contraseña
        password_label = CTkLabel(content, text="Contraseña:", anchor="w")
        password_label.grid(row=3, column=1, sticky="w", padx=5, pady=(8,4))

        self.password_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=300)
        self.password_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=4)

        # Botones
        register_btn = CTkButton(content, text="Registrarme", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_register)
        register_btn.grid(row=5, column=0, sticky="w", pady=(18,0), padx=8)

        login_btn = CTkButton(content, text="Confirmar", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self.on_login)
        login_btn.grid(row=5, column=2, sticky="e", pady=(18,0), padx=8)


        self.mainloop()

class ventanaRegistro(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 415, 400, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Registro')
        
        top_bar_login = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top_bar_login.grid(row=0, column=0, sticky="ew")
        top_bar_login.grid_columnconfigure(1, weight=1)
        # Botón volver
        volver_btn = CTkButton(top_bar_login, text="Volver", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._volver_a_login)
        volver_btn.grid(row=0, column=0, sticky="w", padx=8, pady=10)
        registrolbl = CTkLabel(top_bar_login, text="Registrar usuario", font=('TkHeadingFont', 16), anchor="e")
        registrolbl.grid(row=0, column=2, padx=10, pady=10, sticky="e")
        top_bar_login.grid_columnconfigure(2, weight=0)

        # Frame de contenido
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, padx=20, pady=(8,12), sticky="nsew")
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Nombre
        nombre_label = CTkLabel(content, text="Nombre:", anchor="w")
        nombre_label.grid(row=0, column=0, sticky="w", pady=(4,2))
        self.nombre_entry = CTkEntry(content, placeholder_text="Nombre completo", width=360)
        self.nombre_entry.grid(row=1, column=0, sticky="ew", pady=(0,8))

        # Correo electrónico
        correo_label = CTkLabel(content, text="Correo electrónico:", anchor="w")
        correo_label.grid(row=2, column=0, sticky="w", pady=(4,2))
        self.correo_entry = CTkEntry(content, placeholder_text="correo@ejemplo.com", width=360)
        self.correo_entry.grid(row=3, column=0, sticky="ew", pady=(0,8))

        # Número de documento
        doc_label = CTkLabel(content, text="Número de documento:", anchor="w")
        doc_label.grid(row=4, column=0, sticky="w", pady=(4,2))
        self.doc_entry = CTkEntry(content, placeholder_text="Número de documento", width=360)
        self.doc_entry.grid(row=5, column=0, sticky="ew", pady=(0,8))

        # Contraseña
        pass_label = CTkLabel(content, text="Contraseña:", anchor="w")
        pass_label.grid(row=6, column=0, sticky="w", pady=(4,2))
        self.regpass_entry = CTkEntry(content, placeholder_text="Contraseña", show="*", width=360)
        self.regpass_entry.grid(row=7, column=0, sticky="ew", pady=(0,12))

        # Botón confirmar (vuelve a la pantalla principal)
        confirm_btn = CTkButton(content, text="Confirmar datos", fg_color="#3454d1", hover_color='#34d1bf', text_color="#EFEFEF", command=self._confirmar_registro)
        confirm_btn.grid(row=8, column=0, pady=(4,8), sticky="e")

        # manejar cierre de la ventana para devolver la pantalla principal
        self.protocol("WM_DELETE_WINDOW", self._volver_a_login)

    def _volver_a_login(self):
        # devolver la ventana que abrió este registro y cerrar esta
        if self.master is not None:
            try:
                self.master.deiconify()
            except Exception:
                pass
        self.destroy()

    def _confirmar_registro(self):
        # validar y guardar datos en el perfil del master si existe
        nombre = self.nombre_entry.get().strip()
        correo = self.correo_entry.get().strip()
        doc = self.doc_entry.get().strip()
        if self.master is not None:
            # guardar en master.user_profile si existe
            try:
                if not hasattr(self.master, 'user_profile'):
                    self.master.user_profile = {}
                self.master.user_profile.update({
                    'name': nombre,
                    'email': correo,
                    'doc': doc,
                    # preservar millas si ya existían
                    'millas': self.master.user_profile.get('millas', 0)
                })
            except Exception:
                pass

            try:
                self.master.deiconify()
            except Exception:
                pass
        self.destroy()

class hubAdmin(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 700, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")

        # obtener datos de perfil
        name = ""
        try:
            name = master.user_profile.get('name') if (master and hasattr(master, 'user_profile')) else ""
        except Exception:
            name = ""
        if not name:
            name = master.id_entry.get() if master else ""
        self.title(f'Hub Admin - {name}')

        # top bar (visible, similar a LoginVuelos)
        top_bar = CTkFrame(self, fg_color="#232634", height=48, corner_radius=0)
        top_bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)
        welcome_label = CTkLabel(top_bar, text=f"Bienvenido, Admin {name}!", font=('Verdana', 12, 'bold'))
        welcome_label.grid(row=0, column=0, padx=12, pady=8, sticky="w")

        # contenido principal: dos columnas (botones a la izquierda, perfil a la derecha)
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=16, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        # Columna izquierda: botones verticales
        left_frame = CTkFrame(content, fg_color="transparent")
        left_frame.grid(row=0, column=0, sticky="nsw", padx=(0,12), pady=4)
        left_frame.grid_rowconfigure(10, weight=1)
        cfg_vuelos_btn = CTkButton(left_frame, text="Configurar vuelos", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_config_vuelos)
        cfg_vuelos_btn.grid(row=0, column=0, pady=(4,8), sticky="ew")
        cfg_users_btn = CTkButton(left_frame, text="Configurar usuarios", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_config_usuarios)
        cfg_users_btn.grid(row=1, column=0, pady=(0,8), sticky="ew")
        # espacio y último botón cerrar sesión
        signout_btn = CTkButton(left_frame, text="Cerrar sesión", fg_color="#E04B4B", hover_color='#BF3B3B', command=self._sign_out)
        signout_btn.grid(row=9, column=0, pady=(12,0), sticky="swe")

        # Columna derecha: perfil del admin
        perfil_frame = CTkFrame(content, fg_color="#2B2F42", width=320, corner_radius=6)
        perfil_frame.grid(row=0, column=1, sticky="nsew", padx=(12,0))
        perfil_frame.grid_columnconfigure(0, weight=1)
        CTkLabel(perfil_frame, text="Tus datos", font=('Verdana', 12, 'bold')).grid(row=0, column=0, sticky="w", padx=8, pady=(8,6))
        name_lbl = CTkLabel(perfil_frame, text=f"Nombre: {name}", anchor="w")
        name_lbl.grid(row=1, column=0, sticky="w", padx=8, pady=2)
        doc_lbl = CTkLabel(perfil_frame, text=f"Documento: {master.user_profile.get('doc','') if (master and hasattr(master, 'user_profile')) else master.id_entry.get() if master else ''}", anchor="w")
        doc_lbl.grid(row=2, column=0, sticky="w", padx=8, pady=2)
        email_lbl = CTkLabel(perfil_frame, text=f"Correo: {master.user_profile.get('email','') if (master and hasattr(master, 'user_profile')) else ''}", anchor="w")
        email_lbl.grid(row=3, column=0, sticky="w", padx=8, pady=2)

    def _open_config_vuelos(self):
        # pasar el hub como parent (posicional) y el LoginVuelos como login_master (keyword)
        configVuelos(self, login_master=self.master)

    def _open_config_usuarios(self):
        # igual que arriba: hub como parent, login master separado
        configUsuarios(self, login_master=self.master)

    def _sign_out(self):
        # devolver al login y borrar formulario
        if self.master is not None:
            try:
                self.master.deiconify()
                if hasattr(self.master, 'clear_login_form'):
                    self.master.clear_login_form()
            except Exception:
                pass
        self.destroy()

class hubUsuario(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.master = master
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 700, 420, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")

        name = ""
        mail = ""
        doc = ""
        millas = 0
        try:
            if master and hasattr(master, 'user_profile'):
                name = master.user_profile.get('name','')
                mail = master.user_profile.get('email','')
                doc = master.user_profile.get('doc','')
                millas = master.user_profile.get('millas',0)
        except Exception:
            pass
        if not name:
            name = master.id_entry.get() if master else ""
        self.title(f'Hub Usuario - {name}')

        # top bar
        top_bar = CTkFrame(self, fg_color="#232634", height=48, corner_radius=0)
        top_bar.grid(row=0, column=0, columnspan=2, sticky="ew")
        top_bar.grid_columnconfigure(1, weight=1)
        welcome_label = CTkLabel(top_bar, text=f"Bienvenido, {name}!", font=('Verdana', 12, 'bold'))
        welcome_label.grid(row=0, column=0, padx=12, pady=8, sticky="w")

        # contenido principal: botones izquierda, perfil derecha
        content = CTkFrame(self, fg_color="transparent")
        content.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=16, pady=12)
        self.grid_rowconfigure(1, weight=1)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)

        left_frame = CTkFrame(content, fg_color="transparent")
        left_frame.grid(row=0, column=0, sticky="nsw", padx=(0,12))
        buscar_btn = CTkButton(left_frame, text="Buscar vuelo", fg_color="#3454d1", hover_color='#34d1bf', command=self._open_buscar_vuelo)
        buscar_btn.grid(row=0, column=0, pady=(4,8), sticky="ew")
        ver_reservas_btn = CTkButton(left_frame, text="Ver mis reservas", fg_color="#3454d1", hover_color='#34d1bf', command=self._ver_reservas)
        ver_reservas_btn.grid(row=1, column=0, pady=(0,8), sticky="ew")
        cancelar_btn = CTkButton(left_frame, text="Cancelar reserva", fg_color="#3454D1", hover_color='#34d1bf', command=self._cancelar_reserva)
        cancelar_btn.grid(row=2, column=0, pady=(0,8), sticky="ew")
        editar_btn = CTkButton(left_frame, text="Editar reserva", fg_color="#3454d1", hover_color='#34d1bf', command=self._editar_reserva)
        editar_btn.grid(row=3, column=0, pady=(0,8), sticky="ew")
        # botón para logout también disponible
        logout_btn = CTkButton(left_frame, text="Cerrar sesión", fg_color="#E04B4B", hover_color='#BF3B3B', command=self._sign_out)
        logout_btn.grid(row=9, column=0, pady=(12,0), sticky="swe")

        perfil_frame = CTkFrame(content, fg_color="#2B2F42", corner_radius=6)
        perfil_frame.grid(row=0, column=1, sticky="nsew", padx=(12,0))
        CTkLabel(perfil_frame, text="Tus datos", font=('Verdana', 12, 'bold')).grid(row=0, column=0, sticky="w", padx=8, pady=(8,6))
        CTkLabel(perfil_frame, text=f"Nombre: {name}").grid(row=1, column=0, sticky="w", padx=8)
        CTkLabel(perfil_frame, text=f"Documento: {doc}").grid(row=2, column=0, sticky="w", padx=8)
        CTkLabel(perfil_frame, text=f"Correo: {mail}").grid(row=3, column=0, sticky="w", padx=8)
        self.millas_label = CTkLabel(perfil_frame, text=f"Millas disponibles: {millas}")
        self.millas_label.grid(row=4, column=0, sticky="w", padx=8, pady=(6,8))

    def _open_buscar_vuelo(self):
        # pasar login master para que la búsqueda/reserva pueda actualizar millas
        BuscarVuelo(self, login_master=self.master)

    def _ver_reservas(self):
        messagebox.showinfo("Reservas", "Función 'Ver mis reservas' no implementada aún.")

    def _cancelar_reserva(self):
        messagebox.showinfo("Cancelar", "Función 'Cancelar reserva' no implementada aún.")

    def _editar_reserva(self):
        messagebox.showinfo("Editar", "Función 'Editar reserva' no implementada aún.")

    def actualizar_millas(self):
        try:
            millas = self.master.user_profile.get('millas',0)
            self.millas_label.configure(text=f"Millas disponibles: {millas}")
        except Exception:
            pass

    def _sign_out(self):
        if self.master is not None:
            try:
                self.master.deiconify()
                if hasattr(self.master, 'clear_login_form'):
                    self.master.clear_login_form()
            except Exception:
                pass
        self.destroy()

class BuscarVuelo(CTkToplevel):
    def __init__(self, master=None, login_master=None, **kwargs):
        # master: hub window; login_master: instancia LoginVuelos para actualizar perfil/millas
        super().__init__(master)
        self.login_master = login_master if login_master is not None else kwargs.get('login_master', None)
        self.geometry =(LoginVuelos.CenterWindowToDisplay(self, 415, 400, self._get_window_scaling()))
        self.resizable(False, False)
        # placeholder ciudades y vuelos (añadir "(Todos)" para opción neutra)
        self.cities = ["(Todos)", "Bogotá", "Medellín", "Cali", "Cartagena"]
        self.flights = [
            {'id': 'V001', 'origen': 'Bogotá', 'destino': 'Medellín', 'hora': ['08:00','12:00'], 'price': 120, 'seats': 10},
            {'id': 'V002', 'origen': 'Cali', 'destino': 'Bogotá', 'hora': ['09:00','15:00'], 'price': 150, 'seats': 5},
            {'id': 'V003', 'origen': 'Cartagena', 'destino': 'Bogotá', 'hora': ['07:00','18:00'], 'price': 180, 'seats': 2},
            {'id': 'V004', 'origen': 'Medellín', 'destino': 'Cali', 'hora': ['11:00','16:00'], 'price': 100, 'seats': 8},
        ]

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        # filtros usando CTkOptionMenu y botón con imagen
        filtro_frame = CTkFrame(content, fg_color="transparent")
        filtro_frame.pack(fill='x', pady=(0,8))
        CTkLabel(filtro_frame, text="Origen:").grid(row=0,column=0, padx=4, pady=4, sticky="w")
        self.origen_cb = customtkinter.CTkOptionMenu(filtro_frame, values=self.cities)
        self.origen_cb.grid(row=0,column=1, padx=4, pady=4)
        CTkLabel(filtro_frame, text="Destino:").grid(row=0,column=2, padx=4, pady=4, sticky="w")
        self.destino_cb = customtkinter.CTkOptionMenu(filtro_frame, values=self.cities)
        self.destino_cb.grid(row=0,column=3, padx=4, pady=4)

        # imagen lupa (usa lupa.png en la misma carpeta)
        try:
            self.lupa_img = customtkinter.CTkImage(light_image=Image.open('lupa.png'), size=(20,20))
            buscar_btn = CTkButton(filtro_frame, image=self.lupa_img, text="", width=36, height=36, command=self._buscar)
        except Exception:
            buscar_btn = CTkButton(filtro_frame, text="Buscar", command=self._buscar)
        buscar_btn.grid(row=0, column=4, padx=8)

        # resultados: Listbox con fondo oscuro
        resultado_frame = CTkFrame(content, fg_color="transparent")
        resultado_frame.pack(fill='both', expand=True)
        self.listbox = tk.Listbox(resultado_frame, height=8, bg="#1f2330", fg="#EFEFEF", selectbackground="#3454d1", highlightthickness=0)
        self.listbox.pack(side='left', fill='both', expand=True, padx=(0,8))
        self.scrollbar = tk.Scrollbar(resultado_frame, orient='vertical', command=self.listbox.yview)
        self.scrollbar.pack(side='right', fill='y')
        self.listbox.config(yscrollcommand=self.scrollbar.set)

        action_frame = CTkFrame(content, fg_color="transparent")
        action_frame.pack(fill='x', pady=(8,0))
        reservar_btn = CTkButton(action_frame, text="Reservar", command=self._reservar_seleccion)
        reservar_btn.pack(side='right')

        # inicializar lista completa
        self._llenar_lista(self.flights)

    def _llenar_lista(self, flights):
        self.listbox.delete(0, tk.END)
        for f in flights:
            self.listbox.insert(tk.END, f"{f['id']} | {f['origen']} -> {f['destino']} | ${f['price']} | sillas: {f['seats']}")

    def _buscar(self):
        origen = self.origen_cb.get().strip() if hasattr(self.origen_cb, 'get') else ''
        destino = self.destino_cb.get().strip() if hasattr(self.destino_cb, 'get') else ''
        if origen in ("", "(Todos)"):
            origen = ""
        if destino in ("", "(Todos)"):
            destino = ""
        results = []
        for f in self.flights:
            if origen and origen == f['origen']:
                results.append(f)
            elif destino and destino == f['destino']:
                results.append(f)
        if not origen and not destino:
            results = self.flights
        self._llenar_lista(results)

    def _reservar_seleccion(self):
        sel = self.listbox.curselection()
        if not sel:
            messagebox.showwarning("Seleccionar", "Seleccione primero un vuelo.")
            return
        idx = sel[0]
        # parsear id desde linea
        line = self.listbox.get(idx)
        flight_id = line.split('|')[0].strip()
        flight = next((f for f in self.flights if f['id']==flight_id), None)
        if flight:
            # pasar posicionalmente el parent (self) y login_master por keyword
            ReservarVuelo(self, flight=flight, login_master=self.login_master)

class ReservarVuelo(CTkToplevel):
    def __init__(self, master=None, flight=None, login_master=None, **kwargs):
        # master: ventana que abrió esta ventana; login_master: instancia LoginVuelos para actualizar millas
        super().__init__(master)
        self.login_master = login_master if login_master is not None else kwargs.get('login_master', None)
        self.flight = flight
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 520, 500, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title("Reservar Vuelo")

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)

        CTkLabel(content, text=f"Vuelo: {flight['id']} - {flight['origen']} -> {flight['destino']}").pack(anchor='w', pady=(0,6))
        CTkLabel(content, text=f"Precio por silla: ${flight['price']} - Sillas disponibles: {flight['seats']}").pack(anchor='w')

        # seleccionar número de sillas (max 3) usando CTkOptionMenu
        seats_frame = CTkFrame(content, fg_color="transparent")
        seats_frame.pack(fill='x', pady=(8,8))
        CTkLabel(seats_frame, text="Cantidad de sillas:").grid(row=0,column=0, padx=4)
        self.seats_cb = customtkinter.CTkOptionMenu(seats_frame, values=["1","2","3"], command=lambda v: self._generar_pasajeros())
        self.seats_cb.grid(row=0, column=1, padx=4)

        # horas disponibles usando CTkOptionMenu
        CTkLabel(seats_frame, text="Hora:").grid(row=0, column=2, padx=4)
        horas = [str(h) for h in flight.get('hora',[])]
        self.hora_cb = customtkinter.CTkOptionMenu(seats_frame, values=horas)
        self.hora_cb.grid(row=0, column=3, padx=4)

        # contenedor para datos de pasajeros
        self.pasajeros_frame = CTkFrame(content, fg_color="transparent")
        self.pasajeros_frame.pack(fill='both', expand=True, pady=(8,8))

        # botón confirmar
        confirm_btn = CTkButton(content, text="Confirmar reserva", fg_color="#3454d1", hover_color='#34d1bf', command=self._confirmar)
        confirm_btn.pack(side='right', pady=(8,0))

    def _generar_pasajeros(self, event=None):
        for widget in self.pasajeros_frame.winfo_children():
            widget.destroy()
        try:
            n = int(self.seats_cb.get())
        except Exception:
            n = 0
        for i in range(n):
            CTkLabel(self.pasajeros_frame, text=f"Pasajero {i+1} - Nombre:").grid(row=i*2, column=0, sticky='w', padx=4, pady=(4,0))
            e_nom = CTkEntry(self.pasajeros_frame, placeholder_text="Nombre completo")
            e_nom.grid(row=i*2, column=1, sticky='ew', padx=4, pady=(4,0))
            CTkLabel(self.pasajeros_frame, text=f"Documento:").grid(row=i*2+1, column=0, sticky='w', padx=4, pady=(0,6))
            e_doc = CTkEntry(self.pasajeros_frame, placeholder_text="Documento")
            e_doc.grid(row=i*2+1, column=1, sticky='ew', padx=4, pady=(0,6))
            # guardar referencias
            e_nom._meta = {'tipo':'nombre', 'idx': i}
            e_doc._meta = {'tipo':'doc', 'idx': i}

    def _confirmar(self):
        try:
            n = int(self.seats_cb.get())
        except Exception:
            messagebox.showwarning("Datos", "Selecciones la cantidad de sillas.")
            return
        hora = self.hora_cb.get()
        if not hora:
            messagebox.showwarning("Datos", "Seleccione una hora.")
            return
        pasajeros = []
        for w in self.pasajeros_frame.winfo_children():
            if isinstance(w, CTkEntry) and hasattr(w, "_meta"):
                if w._meta['tipo']=='nombre':
                    pasajeros.append({'nombre': w.get(), 'doc': ''})
        # intentar obtener docs (simple)
        docs = [w.get() for w in self.pasajeros_frame.winfo_children() if isinstance(w, CTkEntry) and getattr(w, "_meta", {}).get('tipo')=='doc']
        for i in range(len(pasajeros)):
            pasajeros[i]['doc'] = docs[i] if i < len(docs) else ''

        total = self.flight['price'] * n
        if messagebox.askyesno("Confirmar", f"Total ${total} por {n} silla(s). Confirmar reserva?"):
            # simular reserva: disminuir sillas y añadir millas al perfil del login_master
            try:
                self.flight['seats'] -= n
            except Exception:
                pass
            if self.login_master is not None:
                if not hasattr(self.login_master, 'user_profile'):
                    self.login_master.user_profile = {'millas': 0}
                # cada reserva suma 500 millas (según especificación)
                self.login_master.user_profile['millas'] = self.login_master.user_profile.get('millas',0) + 500
                # si hay una hubUsuario abierto, intentar actualizar su etiqueta
                try:
                    for w in self.login_master.winfo_children():
                        if isinstance(w, hubUsuario):
                            w.actualizar_millas()
                except Exception:
                    pass
            messagebox.showinfo("Reservado", "Reserva confirmada.")
            self.destroy()
class CrearVuelo(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 600, 400, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Crear Vuelo')

class VerVuelo(CTkToplevel):
     def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 600, 400, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Ver Vuelo')

class BuscarUsuario(CTkToplevel):
    def __init__(self, master=None):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 400, 200, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Buscar Usuario')
        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        CTkLabel(content, text="Documento:").grid(row=0, column=0, sticky='w')
        self.doc_entry = CTkEntry(content, placeholder_text="Documento")
        self.doc_entry.grid(row=1, column=0, sticky='ew', pady=(4,8))
        buscar_btn = CTkButton(content, text="Buscar", command=self._buscar)
        buscar_btn.grid(row=2, column=0, sticky='e')

    def _buscar(self):
        doc = self.doc_entry.get().strip()
        messagebox.showinfo("Buscar", f"Búsqueda de usuario por documento '{doc}' (no implementada).")

class configVuelos(CTkToplevel):
    def __init__(self, master=None, **kwargs):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 500, 300, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Configurar Vuelos')

        login_master = kwargs.get('login_master', None)

        top = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top.pack(fill='x')
        CTkLabel(top, text="Configuración de Vuelos", font=('Verdana', 12, 'bold')).pack(side='left', padx=8, pady=6)
        back_btn = CTkButton(top, text="Volver", fg_color="#3454d1", command=self.destroy)
        back_btn.pack(side='right', padx=8, pady=6)

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        crear_btn = CTkButton(content, text="Crear vuelo", command=lambda: CrearVuelo(self))
        crear_btn.pack(fill='x', pady=6)
        # pasar login_master explícito para evitar duplicar 'master'
        buscar_btn = CTkButton(content, text="Buscar vuelo", command=lambda: BuscarVuelo(self, login_master=login_master))
        buscar_btn.pack(fill='x', pady=6)
        ver_btn = CTkButton(content, text="Ver vuelos con sillas", command=lambda: VerVuelo(self))
        ver_btn.pack(fill='x', pady=6)

class configUsuarios(CTkToplevel):
    def __init__(self, master=None, **kwargs):
        super().__init__(master)
        self.geometry(LoginVuelos.CenterWindowToDisplay(self, 400, 220, self._get_window_scaling()))
        self.resizable(False, False)
        self.configure(fg_color="#2B2F42")
        self.title('Configurar Usuarios')

        login_master = kwargs.get('login_master', None)

        top = CTkFrame(self, fg_color="#232634", height=40, corner_radius=0)
        top.pack(fill='x')
        CTkLabel(top, text="Configuración de Usuarios", font=('Verdana', 12, 'bold')).pack(side='left', padx=8, pady=6)
        back_btn = CTkButton(top, text="Volver", fg_color="#3454d1", command=self.destroy)
        back_btn.pack(side='right', padx=8, pady=6)

        content = CTkFrame(self, fg_color="transparent")
        content.pack(fill='both', expand=True, padx=12, pady=12)
        crear_btn = CTkButton(content, text="Crear/Registrar usuario", command=lambda: ventanaRegistro(self))
        crear_btn.pack(fill='x', pady=6)
        buscar_btn = CTkButton(content, text="Buscar usuario", command=lambda: BuscarUsuario(self))
        buscar_btn.pack(fill='x', pady=6)

# clases restantes (sin cambios funcionales importantes)
class ReservarVuelo_placeholder(CTkToplevel):
    pass

if __name__ == "__main__":
    LoginVuelos()