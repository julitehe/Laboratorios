from Reserva import *
from Vuelo import *
from random import randint

class Usuario:
    def __init__(self):
        self._nombre = None
        self._correo = None
        self._id = 0
        self._contraseña = None
        self._vuelos = [None]

    @property
    def nombre(self): return self._nombre
    
    @property
    def correo(self): return self._correo
    
    @property
    def id(self): return self._id

    @property
    def contraseña(self): return self._contraseña

    @nombre.setter
    def nombre(self, n): self._nombre = n

    @correo.setter
    def correo(self, c): self._correo = c

    @id.setter
    def id(self, id): self._id = id

    @contraseña.setter
    def contraseña(self, con): self._contraseña = con


class Cliente(Usuario):
    def __init__(self):
        super().__init__()
        self.__millas = 0
        self.__reservasCliente = [None]
    
    #user -> usuario, numPasajeros <= 3 añadir condicion
    def reservarVuelo(self, user, codigo, numPasajeros):
        for i in self._vuelos:
            if i.codigo == codigo:
                nuevaR = Reserva(user, i,  numPasajeros)
                nuevaR.añadirPasajeros()
                #Calcular y mostrar el costo y luego mostrar el numero de rerserva            
                numR = randint(1000)
                nuevaR.numReserva(numR)
            else:
                return -1

class Admin(Usuario):
    def __init__(self):
        super().__init__()

    def crearVuelo(self, codigo, numP):
        #como se va a recibir la info de los vuelos? agregar setters
        nuevo = Vuelo(codigo, numP)
        nuevo.origen("Pasto")
        nuevo.destino("Medellin")
        nuevo.horario("10:13")
        nuevo.sillasPref()
        nuevo.sillasEco()

        