from UNAL.proyecto2_poo.Usuario import *
import tkinter as tk

class Aplicacion():
    def __init__(self):
        pass

    window = tk.Tk()

    
    window.geometry("500x500")
    window.title("GUI")

    label = tk.Label(window, text="Log In", font=("Arial", 15))
    label.pack(pady=20)

    window.mainloop()




