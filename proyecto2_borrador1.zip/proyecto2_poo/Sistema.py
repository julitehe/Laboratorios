from Usuario import *
class Sistema():
    def __init__(self):
        self.__usuarios = [None]

    def buscarUsuario(self, id):
        for i in self.__usuarios:
            if i.id == id:
                return self.__usuarios.index(i)
            else:
                return -1 
            
    def registro(self):
        nuevo = Usuario()
        # como se van a recibir los datos de registro? agregar setters
        self.__usuarios.append(nuevo)
            
    def logIn(self, id, contraseña):
        user = Sistema.buscarUsuario(id)
        if  user == -1:
            return False
        if user.contraseña == contraseña:
            return True
        


