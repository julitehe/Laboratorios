/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.biblioteca;

/**
 *
 * @author xsraws
 */
public class Usuario {
private String nombre;

    private String contraseña;
    private int librosMax;
    private int numLibrosPrestados;
    private final Libro librosPrestados[];

    public Usuario(String nom, String contra){
        this.nombre = nom;
        this.contraseña = contra;

        if (nombre.startsWith("Admin")){
            librosMax = 1;
            librosPrestados = new Libro[librosMax];
        }
        else if(nombre.startsWith("Profe")){
            librosMax = 3;
            librosPrestados = new Libro[librosMax];
        }
        else{
            librosMax = 5;
            librosPrestados = new Libro[librosMax];            
        }
    }

    public void setNombre(String n){
        this.nombre = n;}

    public void setLibrosMax(int numMax){
        this.librosMax = numMax;}

    public void setNumLibrosPrestados(int numPres){
        this.numLibrosPrestados = numPres;}
    
    public String getNombre(){
        return nombre;}

    public String getContraseña(){
        return contraseña;}

    public int getLibrosMax(){
        return librosMax;}

    public int getNumLibrosPrestados(){
        return numLibrosPrestados;}
    

    public void agregarLibrosPrestados(Libro l){
        if (numLibrosPrestados < librosPrestados.length){
            librosPrestados[numLibrosPrestados] = l;
            numLibrosPrestados++;        
        }
    }

    public boolean cambiarContraseña(String actual, String nueva){
        if (actual.equals(contraseña)){
            contraseña = nueva;
            return true;
        }
        else{
            System.out.println("La contraseña ingresada no corresponde con la contraseña actual.");
            return false;
        }
    }

    public Libro getLibroPrestadoEn(int i) {
        if (i >= 0 && i < numLibrosPrestados) {
            return librosPrestados[i];
        }
        return null;
    }

    public void eliminarLibroPrestadoEn(int pos) {
        for (int j = pos + 1; j < numLibrosPrestados; j++) {
            librosPrestados[j - 1] = librosPrestados[j];
        }
        librosPrestados[numLibrosPrestados - 1] = null;
        numLibrosPrestados--;
    }

    public String verLibrosPrestados(){
        if (numLibrosPrestados == 0){
            return ("Aún no has prestado ningún libro :(");
        }
        
        else if(numLibrosPrestados > 0 ){
            System.out.println("\nLibros prestados a "+ nombre +": " + numLibrosPrestados);
            for(int i = 0; i < numLibrosPrestados; i++){
                System.out.println("#" + (i + 1) + " " + librosPrestados[i].getTitulo() + ", " +
                        librosPrestados[i].getAutor() + "Cod: " + librosPrestados[i].getCodigo());
            }            
            System.out.println("\n");
        }
        return null;
    }
    
    @Override
    public String toString(){
        return "\n--------- Información sobre el usuario --------- \nNombre: " + nombre +"\nNúmero de libros prestados: " + numLibrosPrestados + "\n";}
}
